package hr.java.restaurant.model;

import hr.java.production.main.Main;
import hr.java.utils.DataInput;

import java.util.Scanner;


/**
 * Klasa Category koja sadrzi razna svojstva za objekt
 * Sadrži metode inputCategories, ispisCategory
 */
public class Category extends Entity {
    private String name;
    private String description;

    public Category(Long id, String name, String description) {
        super(id);
        this.name = name;
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * Builder klasa za Category klasu
     */
    public static class Builder {
        private Long id;
        private String name;
        private String description;

        public Builder withId(Long id) {
            this.id = id;
            return this;
        }

        public Builder withName(String name) {
            this.name = name;
            return this;
        }

        public Builder withDescription(String description) {
            this.description = description;
            return this;
        }

        public Category build() {
            return new Category(id, name, description);
        }
    }

    /**
     * Metoda inputCategories za upis kategorija (upis svojstava)
     * @param n kolicinu kategorija koje zelimo upisati
     * @param sc Objekt klase Scanner za upis
     * @return vraća polje vrste Category[]
     */
    public static Category[] inputCategories(int n, Scanner sc) {
        Main.log.info("Pozvana metoda inputCategories.");
        Category[] categories = new Category[n];
        for (int i = 0; i < n; i++) {
            System.out.println((i + 1) + ". kategorija: ");
            Main.log.info("Upis imena " + (i + 1) + ". kategorije: ");
            String name = DataInput.nameInput(sc, categories, i, "Upiši ime kategorije: ");
            System.out.println("Upiši opis: ");
            Main.log.info("Upis opisa " + (i + 1) + ". kategorije: ");
            String description = sc.nextLine();
            categories[i] = new Category((long) i, name, description);
        }
        return categories;
    }

    /**
     * Metoda za ispis svojstava objekta klase Category
     */
    public void ispisCategory() {
        Main.log.info("Pozvana metoda ispisCategory.");
        System.out.println("Ime kategorije: " + getName() + " - Opis kategorije: " + getDescription());
    }
}
