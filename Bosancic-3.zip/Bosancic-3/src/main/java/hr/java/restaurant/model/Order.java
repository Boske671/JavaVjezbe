package hr.java.restaurant.model;

import hr.java.production.main.Main;
import hr.java.utils.InputValidator;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import static hr.java.restaurant.model.Restaurant.ispisRestoran;


/**
 * Klasa Order koja sadrzi razna svojstva za objekt
 * Sadrži metode poput inputOrders, ispisOrder
 */
public class Order extends Entity {
    private Restaurant restaurant;
    private Meal[] meals;
    private Deliverer deliverer;


    /**
     * Konstruktor za kreiranje objekta klase `Order`, koja predstavlja narudžbu u restoranu,
     * uključujući podatke o restoranu, naručenim jelima, dostavljaču i datumu te vremenu dostave.
     *
     * @param id Jedinstveni identifikator narudžbe.
     * @param restaurant Objekt klase `Restaurant` koji predstavlja restoran iz kojeg se narudžba šalje.
     * @param meals Polje objekata `Meal` koje sadrži sva jela uključena u narudžbu.
     * @param deliverer Objekt klase `Deliverer` koji predstavlja dostavljača zaduženog za isporuku narudžbe.
     * @param deliveryDateAndTime Vrijeme i datum dostave narudžbe kao objekt `LocalDateTime`.
     */

    public Order(Long id, Restaurant restaurant, Meal[] meals, Deliverer deliverer, LocalDateTime deliveryDateAndTime) {
        super(id);
        this.restaurant = restaurant;
        this.meals = meals;
        this.deliverer = deliverer;
        this.deliveryDateAndTime = deliveryDateAndTime;
    }

    private LocalDateTime deliveryDateAndTime;

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public Meal[] getMeals() {
        return meals;
    }

    public void setMeals(Meal[] meals) {
        this.meals = meals;
    }

    public Deliverer getDeliverer() {
        return deliverer;
    }

    public void setDeliverer(Deliverer deliverer) {
        this.deliverer = deliverer;
    }

    public LocalDateTime getDeliveryDateAndTime() {
        return deliveryDateAndTime;
    }

    public void setDeliveryDateAndTime(LocalDateTime deliveryDateAndTime) {
        this.deliveryDateAndTime = deliveryDateAndTime;
    }


    /**
     * Metoda za unos podataka o narudžbama, uključujući restoran, jela, dostavljača i datum i vrijeme dostave.
     * Korisnik unosi podatke putem konzole, a metoda vraća polje objekata `Order` s odgovarajućim podacima.
     *
     * @param n Broj narudžbi koje korisnik želi unijeti.
     * @param restaurants Polje dostupnih objekata `Restaurant`, tj. restorana iz kojih se mogu naručiti jela.
     * @param meals Polje dostupnih objekata `Meal`, tj. jela koja su dostupna za naručivanje.
     * @param deliverers Polje dostupnih objekata `Deliverer`, tj. dostavljača koji mogu dostaviti narudžbe.
     * @param sc Objekt klase `Scanner` koji se koristi za unos podataka s konzole.
     * @return Polje objekata tipa `Order` koje sadrži sve unesene narudžbe s njihovim podacima.
     */

    public static Order[] inputOrders(int n, Restaurant[] restaurants, Meal[] meals, Deliverer[] deliverers, Scanner sc) {
        Main.log.info("Pozvana metoda inputOrders.");
        Order[] orders = new Order[n];

        for (int i = 0; i < n; i++) {
            Main.log.info("Upis "  + (i + 1) + ". Order-a: ");
            System.out.println((i + 1) + ". narudzba: ");
            System.out.println("Upisi index od 0 do " + (restaurants.length - 1) + " za restoran: ");
            for (int k = 0; k < meals.length; k++) {
                System.out.print("index: " + k + " - ");
                ispisRestoran(restaurants[k]);
            }
            int indexRestoran = InputValidator.integerValidator(sc);

            System.out.println("Upisi broj jela: ");
            int brJela = InputValidator.integerValidator(sc);
            Meal novaJela[] = new Meal[brJela];
            System.out.println("Odaberi index od 0 do " + (meals.length - 1));
            for (int k = 0; k < meals.length; k++) {
                System.out.print("index: " + k + " - ");
                meals[k].ispisMeal();
            }
            for (int j = 0; j < brJela; j++) {
                int index = InputValidator.integerValidator(sc);
                novaJela[j] = meals[index];
            }


            System.out.println("Upisi broj dostavljaca: ");
            for (int k = 0; k < deliverers.length; k++) {
                System.out.print("index: " + k + " - ");
                deliverers[k].ispisDeliverer();
            }
            int indexDel = InputValidator.integerValidator(sc);
            sc.nextLine();

            System.out.println("Upisi datum (dd.MM.yyyy. HH:mm) : ");
            String datum = sc.nextLine();
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy. HH:mm");
            LocalDateTime newDate = LocalDateTime.parse(datum, dateFormat);
            orders[i] = new Order((long) i, restaurants[indexRestoran], novaJela, deliverers[indexDel], newDate);
        }
        sc.close();
        return orders;
    }


    public static void restoranNajskupljaDostava(Order[] orders) {

        BigDecimal max = BigDecimal.ZERO;
        int[] indexiNarudzbi = new int[orders.length];
        int brojac = 0; // Broji koliko narudžbi ima maksimalnu cijenu

        for (int i = 0; i < orders.length; i++) {
            BigDecimal ukCijena = BigDecimal.ZERO;

            // Računanje ukupne cijene narudžbe
            for (int j = 0; j < orders[i].getMeals().length; j++) {
                ukCijena = ukCijena.add(orders[i].getMeals()[j].getPrice());
            }

            // Ako je pronađena nova maksimalna cijena, ažuriraj max i resetiraj brojač
            if (ukCijena.compareTo(max) > 0) {
                max = ukCijena;
                brojac = 0; // Resetiramo brojač jer imamo novu maksimalnu cijenu
                indexiNarudzbi[brojac] = i; // Spremamo trenutni indeks narudžbe
                brojac++;
            }
            // Ako je cijena jednaka trenutnoj maksimalnoj cijeni, dodaj indeks u niz
            else if (ukCijena.compareTo(max) == 0) {
                indexiNarudzbi[brojac] = i;
                brojac++;
            }
        }


        // Ispis svih restorana s najskupljom narudžbom bez duplikata
        System.out.println("Restorani s najskupljom narudžbom:");
        for (int i = 0; i < brojac; i++) {
            boolean ispisan = false;
            Order najskupljaNarudzba = orders[indexiNarudzbi[i]];

            // Provjeravamo da li je restoran već ispisan
            for (int j = 0; j < i; j++) {
                if (najskupljaNarudzba.getRestaurant().getName().equals(orders[indexiNarudzbi[j]].getRestaurant().getName())) {
                    ispisan = true;
                    break; // Ako je pronađen duplikat, prekidamo unutarnju petlju
                }
            }

            // Ako restoran nije već ispisan, ispisujemo ga
            if (!ispisan) {
                System.out.println("Ime restorana: " + najskupljaNarudzba.getRestaurant().getName());
                System.out.println("Adresa: " + najskupljaNarudzba.getRestaurant().getAddress().getCity());
                System.out.println("Cijena narudžbe: " + max);
                System.out.println("-----");
            }
        }
    }


}
