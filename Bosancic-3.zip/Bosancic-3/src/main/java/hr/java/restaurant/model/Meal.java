package hr.java.restaurant.model;

import hr.java.production.main.Main;
import hr.java.utils.DataInput;
import hr.java.utils.InputValidator;

import java.math.BigDecimal;
import java.util.Scanner;


/**
 * Klasa Meal koja sadrzi razna svojstva za objekt
 * Sadrži metode poput inputMeals, ispisMeal
 */
public class Meal extends Entity {

    private String name;
    private Category category;
    private Ingredient[] ingredients;
    private BigDecimal price;


    /**
     * Konstruktor klase Meal
     *
     * @param id          parametar vrste long (od nadklase Entity)
     * @param name        parametar koji je ime Meal-a
     * @param category    već stvoreni objekt potreban za stvaranje objekta Meal
     * @param ingredients polje vrste "Ingredient"
     * @param price       parametar koji je cijena "Meal"-a
     */
    public Meal(Long id, String name, Category category, Ingredient[] ingredients, BigDecimal price) {
        super(id);
        this.name = name;
        this.category = category;
        this.ingredients = ingredients;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Ingredient[] getIngredients() {
        return ingredients;
    }

    public void setIngredients(Ingredient[] ingredients) {
        this.ingredients = ingredients;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }


    /**
     * Metoda za unos podataka o jelima, uključujući naziv jela, kategoriju, sastojke i cijenu.
     * Metoda traži od korisnika da unese sve potrebne podatke putem konzole.
     *
     * @param n           Broj jela koje korisnik želi unijeti.
     * @param categories  Polje dostupnih kategorija jela koje korisnik može odabrati.
     * @param ingredients Polje dostupnih sastojaka koje korisnik može odabrati za svako jelo.
     * @param sc          Objekt klase Scanner koji se koristi za unos podataka s konzole.
     * @return Polje objekata tipa `Meal` koje sadrži sva unesena jela s pridruženim podacima.
     */

    public static Meal[] inputMeals(int n, Category[] categories, Ingredient[] ingredients, Scanner sc) {
        Main.log.info("Pozvana metoda inputMeals.");
        Meal[] meals = new Meal[n];
        for (int i = 0; i < n; i++) {

            System.out.println((i + 1) + ". jelo: ");
            Main.log.info("Upis imena " + (i + 1) + ". jela: ");
            String name = DataInput.nameInput(sc, meals, i, "Upiši ime jela: ");
            System.out.println("Upisi index od 0 do " + (categories.length - 1) + ", " + (i + 1) + ". jela: ");
            Main.log.info("Upis indexa kategorije " + (i + 1) + ". jela: ");
            for (int j = 0; j < categories.length; j++) {
                System.out.println("Index: " + j + " - ime: " + categories[j].getName() + " - opis: " + categories[j].getDescription());
            }


            int indexKat = InputValidator.integerValidator(sc);

            System.out.println("Upisi broj sastojaka " + (i + 1) + ". jela: ");
            Main.log.info("Upis broja sastojaka " + (i + 1) + ". jela: ");
            int brSastojaka = InputValidator.integerValidator(sc);
            sc.nextLine();

            for (int j = 0; j < ingredients.length; j++) {
                System.out.println("Index: " + j + " - ime: " + ingredients[j].getName() + " - kategorija: " + ingredients[j].getCategory().getName() + " - kalorije: " + ingredients[j].getKcal() + " - metoda pripreme: " + ingredients[j].getPreparationMethod());
            }

            Ingredient[] sastojci = new Ingredient[brSastojaka];


            for (int j = 0; j < brSastojaka; j++) {
                Main.log.info("Upis indexa sastojka " + (i + 1) + ". jela: ");
                System.out.println("Upisi index od 0 do " + (ingredients.length - 1) + ", " + (i + 1) + ". jela: ");
                int indexSastojka = InputValidator.integerValidator(sc);
                sastojci[j] = ingredients[indexSastojka];
            }
            Main.log.info("Upis cijene " + (i + 1) + ". jela: ");
            System.out.println("Upisi cijenu: " + (i + 1) + ". jela: ");
            BigDecimal cijena = InputValidator.bigDecimalValidator(sc);
            sc.nextLine();
            meals[i] = new Meal((long) i, name, categories[indexKat], sastojci, cijena);
        }
        return meals;
    }


    public static void ispisVrstiJela(Meal[] meals) {
        BigDecimal maksDec = BigDecimal.ZERO;
        BigDecimal minDec = BigDecimal.valueOf(999999);
        Meal max = null;
        Meal min = null;
        for (int i = 0; i < meals.length; i++) {
            BigDecimal brkal = BigDecimal.ZERO;
            for (int j = 0; j < meals[i].getIngredients().length; j++) {
                brkal = brkal.add(meals[i].getIngredients()[j].getKcal());
            }

            if (brkal.compareTo(maksDec) == 1) {
                max = meals[i];
                maksDec = brkal;
            }
            if (brkal.compareTo(minDec) == -1) {
                min = meals[i];
                minDec = brkal;
            }
        }
        System.out.println("MIN: ");
        if (min instanceof VeganMeal) {
            ((VeganMeal) min).ispisVeganMeal();
        } else if (min instanceof VegetarianMeal) {
            ((VegetarianMeal) min).ispisVegetarianMeal();
        } else if (min instanceof MeatMeal) {
            ((MeatMeal) min).ispisMeatMeal();
        }
        System.out.println("MAX: ");
        if (max instanceof VeganMeal) {
            ((VeganMeal) max).ispisVeganMeal();
        } else if (max instanceof VegetarianMeal) {
            ((VegetarianMeal) max).ispisVegetarianMeal();
        } else if (max instanceof MeatMeal) {
            ((MeatMeal) max).ispisMeatMeal();
        }
    }


    public void ispisMeal() {
        System.out.println("Ime: " + (getName()) + " - Price: " + getPrice());
        getCategory().ispisCategory();
        for (Ingredient ingredient : ingredients) {
            ingredient.ispisIngredient();
        }
    }
}
