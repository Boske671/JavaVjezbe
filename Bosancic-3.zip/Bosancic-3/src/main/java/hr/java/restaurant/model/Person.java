package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;

public abstract class Person extends Entity {
    private String firstName;
    private String lastName;

    public Person(Long id, String firstName, String lastName) {
        super(id);
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public static void najvecaPlacaZaposlenika(Person[] people)
    {
        System.out.println("Zaposlenik s najvećom plaćom: ");
        BigDecimal maks = BigDecimal.ZERO;
        Person osobaNajPlaca = null;
        for (int i = 0; i < people.length; i++)
        {
            Contract contract = null;
            if (people[i] instanceof Chef)
            {
                contract = ((Chef) people[i]).getContract();
            } else if (people[i] instanceof Waiter)
            {
                contract = ((Waiter) people[i]).getContract();
            } else if (people[i] instanceof Deliverer)
            {
                contract = ((Deliverer) people[i]).getContract();
            }

            if (contract.getSalary().compareTo(maks) > 0)
            {
                maks = contract.getSalary();
                osobaNajPlaca = people[i];
            }
        }
        if (osobaNajPlaca instanceof Chef)
        {
            ((Chef) osobaNajPlaca).ispisChef();
        } else if (osobaNajPlaca instanceof Waiter)
        {
            ((Waiter) osobaNajPlaca).ispisWaiter();
        } else if (osobaNajPlaca instanceof Deliverer)
        {
            ((Deliverer) osobaNajPlaca).ispisDeliverer();
        }
    }

    public static void najduziUgovorZaposlenika(Person[] people)
    {
        System.out.println("Zaposlenik s najdužim ugovorom (koji je najranije započeo): ");
        long max = 0;
        Person najUgovor = null;

        for (int i = 0; i < people.length; i++)
        {
            Contract contract = null;
            if (people[i] instanceof Chef)
            {
                contract = ((Chef) people[i]).getContract();
            } else if (people[i] instanceof Waiter)
            {
                contract = ((Waiter) people[i]).getContract();
            } else if (people[i] instanceof Deliverer)
            {
                contract = ((Deliverer) people[i]).getContract();
            }
            long days1 = ChronoUnit.DAYS.between(contract.getStartDate(), contract.getEndDate());
            if (days1 > max)
            {
                najUgovor = people[i];
                max = days1;
            }
        }

        if (najUgovor instanceof Chef)
        {
            ((Chef) najUgovor).ispisChef();
        } else if (najUgovor instanceof Waiter)
        {
            ((Waiter) najUgovor).ispisWaiter();
        } else if (najUgovor instanceof Deliverer)
        {
            ((Deliverer) najUgovor).ispisDeliverer();
        }
    }
}
