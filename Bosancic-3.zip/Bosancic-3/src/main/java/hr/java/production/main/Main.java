package hr.java.production.main;

import hr.java.restaurant.model.*;

import java.math.BigDecimal;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Main klasa, služi za korištenje ostalih klasa i poziv metoda
 */
public class Main
{

    public static final BigDecimal MINIMALNA_PLACA = new BigDecimal("800");
    public static Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args)
    {

        log.info("Pocinje main");
        Scanner sc = new Scanner(System.in);

        Category[] categories = Category.inputCategories(3, sc);
        Ingredient[] ingredients = Ingredient.inputIngredients(3, categories, sc);
        //ingredients[2].ispisIngredient();
        Meal[] meals = Meal.inputMeals(3, categories, ingredients, sc);
        //meals[2].ispisMeal();
        Chef[] chefs = Chef.inputChefs(3, sc);
        Deliverer[] deliverers = Deliverer.inputDeliverers(3, sc);
        Waiter[] waiters = Waiter.inputWaiters(3, sc);
        Restaurant[] restaurants = Restaurant.inputRestaurants(3, meals, chefs, waiters, deliverers, sc);
        Order[] orders = Order.inputOrders(3, restaurants, meals, deliverers, sc);
        Order.restoranNajskupljaDostava(orders);


        /*
        Chef[] chefs = inputChefs(1, sc);
        Deliverer[] deliverers = inputDeliverers(1, sc);
        Person people[] = new Person[1];
        people[0] = chefs[0];
        people[1] = deliverers[0];
        people[2] = waiters[0];

        Person.najvecaPlacaZaposlenika(people);
        Person.najduziUgovorZaposlenika(people);


        Chef chef1 = new Chef.Builder().withFirstName("sef1").build();
        Waiter waiter1 = new Waiter.Builder().withFirstName("waiter1").build();
        Deliverer deliverer1 = new Deliverer.Builder().withFirstName("deliverer1").build();
        Address address1 = new Address.Builder().withStreet("ulica1").build();
        Category category1 = new Category.Builder().withName("cat1").build();

        Ingredient[] ingredientsVegan = new Ingredient[] { new Ingredient( (long) 1, "jabuka", new Category((long)1, "voce", "opisvoce"), BigDecimal.valueOf(10), "spremanjejabuke"),
                new Ingredient( (long) 5, "jabuka", new Category((long)1, "voce", "opisvoce"), BigDecimal.valueOf(60), "spremanjejabuke")};
        VeganMeal prviVegan = new VeganMeal ((long) 1, "prvoVeganJelo", new Category((long) 1, "voce", "opisvoce"), ingredientsVegan, BigDecimal.valueOf(100), "aaaaaaaaa");

        Ingredient[] ingredientsVegetarian = new Ingredient[] { new Ingredient( (long) 2, "kruska", new Category((long)1, "voce", "opisvoce"), BigDecimal.valueOf(15), "spremanjekruske")};
        VegetarianMeal prviVegetarian = new VegetarianMeal((long) 1, "prvoVegetarianJelo", new Category((long)1, "voce", "opisvoce"), ingredientsVegetarian, BigDecimal.valueOf(100), "bbbbbbbbbbbb");

        Ingredient[] ingredientsMeat = new Ingredient[] { new Ingredient( (long) 3,"banana", new Category((long)1, "voce", "opisvoce"), BigDecimal.valueOf(20), "spremanjebanane")};
        MeatMeal prviMeat = new MeatMeal((long) 1, "prvoMeatJelo", new Category((long)1, "voce", "opisvoce"), ingredientsMeat, BigDecimal.valueOf(100), BigDecimal.valueOf(100));

        Meal[] meals123 = new Meal[3];
        meals123[0] = prviVegetarian;
        meals123[1] = prviVegan;
        meals123[2] = prviMeat;
        Meal.ispisVrstiJela(meals123);

        */
        sc.close();
    }
}
/*
imetKat1
opisKat1
imeKat2
opisKat2
imeKat3
opisKat3
imeSas1
0
100
metodaPripreme1
imeSas2
1
200
metodaPripreme2
imeSas3
2
300
metodaPripreme3
imeJelo1
0
1
1
120
imeJelo2
2
1
2
200
imeJelo3
2
1
1
300
imeChef1
prezimeChef1
10000
01.01.2022.
05.05.2024.
1
500
imeChef2
prezimeChef2
11000
20.05.2021.
10.04.2023.
2
600
imeChef3
prezimeChef3
12000
01.05.2019.
15.04.2024.
2
600
imeDeliverer1
prezimeDeliverer1
6000
01.08.2015.
27.12.2018.
1
200
imeDeliverer2
prezimeDeliverer2
5000
02.09.2017.
02.12.2018.
2
200
imeDeliverer3
prezimeDeliverer3
4000
01.08.2012.
27.12.2015.
1
400
imeWaiter1
prezimeWaiter1
6000
01.08.2015.
27.12.2016.
1
400
imeWaiter2
prezimeWaiter2
6000
01.08.2016.
20.10.2018.
1
100
imeWaiter3
prezimeWaiter3
5000
01.08.2012.
27.12.2016.
1
400
imeRestoran1
restoranImeUlice1
restoranKucniBroj1
restoranGrad1
restoranPosBr1
1
0
1
1
1
1
1
1
imeRestoran2
restoranImeUlice2
restoranKucniBroj2
restoranGrad2
restoranPosBr2
1
0
1
1
1
1
1
1
imeRestoran3
restoranImeUlice3
restoranKucniBroj23
restoranGrad3
restoranPosBr3
1
0
1
1
1
1
1
1
0
1
1
1
05.05.2004. 10:10
0
1
1
1
10.10.2024. 20:20
0
1
1
1
05.05.2008. 18:30
 */
