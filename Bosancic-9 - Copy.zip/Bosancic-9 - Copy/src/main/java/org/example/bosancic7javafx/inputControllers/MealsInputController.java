package org.example.bosancic7javafx.inputControllers;

import hr.java.restaurant.model.Category;
import hr.java.restaurant.model.Database;
import hr.java.restaurant.model.Ingredient;
import hr.java.restaurant.model.Meal;
import hr.java.restaurant.repository.CategoriesRepository;
import hr.java.restaurant.repository.IngredientsRepository;
import hr.java.restaurant.repository.MealsRepository;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashSet;

public class MealsInputController
{

    @FXML
    private TextField nameInput;
    @FXML
    private ComboBox<Category> categoryCombobox;
    @FXML
    private ComboBox<Ingredient> ingredientCombobox;
    @FXML
    private TextField priceInput;

    HashSet<Ingredient> selectedIngredients = new HashSet<>();
    Database db = new Database();
    public void addItem() throws SQLException
    {
        StringBuilder errors = new StringBuilder();

        String name = nameInput.getText().trim();
        if (name.isEmpty()) {
            errors.append("Name cannot be empty.\n");
        }

        BigDecimal price;
        try {
            price = new BigDecimal(priceInput.getText().trim());
            if (price.compareTo(BigDecimal.ZERO) <= 0) {
                errors.append("Price must be greater than zero.\n");
            }
        } catch (NumberFormatException e) {
            price = null;
            errors.append("Price must be a valid number.\n");
        }

        Category category = categoryCombobox.getSelectionModel().getSelectedItem();
        if (category == null) {
            errors.append("A category must be selected.\n");
        }

        if (selectedIngredients.isEmpty()) {
            errors.append("At least one ingredient must be added.\n");
        }

        if (errors.length() > 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(errors.toString());
            alert.showAndWait();
            return;
        }

        Meal meal = new Meal(0l, name, category, selectedIngredients, price);
        db.addMeal(meal);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("Meal added successfully.");
        alert.showAndWait();

        clearInputs();
    }

    private void clearInputs() {
        nameInput.clear();
        priceInput.clear();
        categoryCombobox.getSelectionModel().clearSelection();
        selectedIngredients.clear();
    }

    public void displayCombobox() throws SQLException
    {
        categoryCombobox.getItems().setAll(db.getAllCategories());
        if (!categoryCombobox.getItems().isEmpty()) {
            categoryCombobox.getSelectionModel().select(0);
        }

        ingredientCombobox.getItems().setAll(db.getAllIngredients());
        if (!ingredientCombobox.getItems().isEmpty()) {
            ingredientCombobox.getSelectionModel().select(0);
        }
    }

    public void addIngredient(ActionEvent event) {
        Ingredient ingredient = ingredientCombobox.getSelectionModel().getSelectedItem();
        if (ingredient != null && !selectedIngredients.contains(ingredient)) {
            selectedIngredients.add(ingredient);
        }
    }

    public void initialize() throws SQLException
    {
        displayCombobox();
    }
}
