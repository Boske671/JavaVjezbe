package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Category;
import hr.java.restaurant.model.Database;
import hr.java.restaurant.repository.CategoriesRepository;
import hr.java.utils.FileNames;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.awt.*;
import java.io.*;
import java.sql.SQLException;
import java.util.List;

public class CategoriesSearchController {

    @FXML
    private Button searchButton;

    @FXML
    private TextField beveragesNameInput;

    @FXML
    private TableView<Category> categoryTable;

    @FXML
    private TableColumn<Category, Long> beveragesIDColumn;

    @FXML
    private TableColumn<Category, String> beveragesNameColumn;

    @FXML
    private TableColumn<Category, String> beveragesDescriptionColumn;

    @FXML
    private TableColumn<Category, ImageView> imageColumn;

    @FXML
    private TableColumn<Category, Category> deleteDolumn;

    private CategoriesRepository categoriesRepository = new CategoriesRepository();
    private Database database = new Database();

    public void outputCategoriesToTable() throws SQLException {
        // Učitavanje kategorija iz repository-a
        List<Category> categories = database.getAllCategories();


        // Pretvaranje liste u ObservableList
        ObservableList<Category> observableCategories = FXCollections.observableArrayList(categories);

        // Filtriranje kategorija na temelju unosa u beveragesNameInput
        if (beveragesNameInput != null && !beveragesNameInput.getText().isEmpty()) {
            String filterText = beveragesNameInput.getText().toLowerCase();
            observableCategories = FXCollections.observableArrayList(
                    categories.stream()
                            .filter(category -> category.getName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        beveragesIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        beveragesNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        beveragesDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));

        imageColumn.setCellValueFactory(param -> {
            Category category = param.getValue();
            ImageView imageView = new ImageView();
            try (BufferedReader bufferedReader = new BufferedReader(new FileReader(FileNames.ImageFolder)))
            {
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    if (line.equals(category.getName())) {
                        Image image = new Image(bufferedReader.readLine());
                        imageView = new ImageView(image);
                        imageView.setImage(image);
                        imageView.setFitWidth(50);
                        imageView.setFitHeight(50);


                    }
                }
            } catch (FileNotFoundException e)
            {
                throw new RuntimeException(e);
            } catch (IOException e)
            {
                throw new RuntimeException(e);
            }
            return new ReadOnlyObjectWrapper<>(imageView);
        });

        // Omogućite uređivanje ćelija za beveragesNameColumn
        beveragesNameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        beveragesNameColumn.setOnEditCommit(event -> {
            Category category = event.getRowValue();
            category.setName(event.getNewValue());
            try {
                database.updateCategory(category);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        // Omogućite uređivanje ćelija za beveragesDescriptionColumn
        beveragesDescriptionColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        beveragesDescriptionColumn.setOnEditCommit(event -> {
            Category category = event.getRowValue();
            category.setDescription(event.getNewValue());
            try {
                database.updateCategory(category); // Ažurirajte kategoriju u bazi podataka
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        deleteDolumn.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue()));
        deleteDolumn.setCellFactory(param -> new TableCell<Category, Category>() {
            private final Button deleteButton = new Button("Delete");

            @Override
            protected void updateItem(Category category, boolean empty) {
                super.updateItem(category, empty);

                if (category == null) {
                    setGraphic(null);
                    return;
                }

                setGraphic(deleteButton);
                deleteButton.setOnAction(event -> {
                    try {
                        database.deleteCategory(category);
                        categoryTable.getItems().remove(category);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        });

        // Postavljanje podataka u TableView
        categoryTable.setItems(observableCategories);
        categoryTable.setEditable(true); // Omogućite uređivanje TableView
    }

    public void FilterTable() {
        // Implementirajte filtriranje ako je potrebno
    }

    // Funkcija za "postavu" scene kada se prvi put loada
    @FXML
    public void initialize() throws SQLException {
        outputCategoriesToTable();
    }
}