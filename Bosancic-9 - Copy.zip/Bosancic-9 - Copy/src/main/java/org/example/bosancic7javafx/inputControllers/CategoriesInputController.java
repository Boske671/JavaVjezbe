package org.example.bosancic7javafx.inputControllers;

import hr.java.restaurant.model.Category;
import hr.java.restaurant.model.Database;
import hr.java.restaurant.repository.CategoriesRepository;
import hr.java.utils.FileNames;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;

public class CategoriesInputController
{

    private String filePath;
    private Category category = new Category(null, null, null);

    @FXML
    private TextField nameInput;

    @FXML
    private TextField descriptionInput;

    private Database database = new Database();

    public void addItem(ActionEvent event) throws SQLException
    {
        boolean isValid = true;
        StringBuilder errors = new StringBuilder();

        // Retrieve and validate inputs
        String name = nameInput.getText().trim();
        String description = descriptionInput.getText().trim();

        if (name.isEmpty()) {
            isValid = false;
            errors.append("Name cannot be empty.\n");
        }
        if (description.isEmpty()) {
            isValid = false;
            errors.append("Description cannot be empty.\n");
        }

        // Display errors or proceed
        if (!isValid) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("Invalid Category Details");
            alert.setContentText(errors.toString());
            alert.showAndWait();
        } else {
            category.setName(name);
            category.setDescription(description);
            category.setId(0l);
            database.addCategory(category);
            try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(FileNames.ImageFolder, true))) {
                bufferedWriter.write(category.getName());
                bufferedWriter.newLine();
                bufferedWriter.write(filePath);
                bufferedWriter.newLine();
            } catch (IOException e)
            {
                throw new RuntimeException(e);
            }
            // Success alert
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Category added successfully!");
            alert.showAndWait();

            clearInputs();
        }
    }

    private void clearInputs() {
        nameInput.clear();
        descriptionInput.clear();
    }

    public void openImageOpener()
    {
        JFileChooser fc = new JFileChooser();
        int returnVal = fc.showOpenDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            System.out.println(file.getAbsolutePath());
            filePath = file.getAbsolutePath();
        }
    }

    public void saveImage(String name, String path)
    {

    }
}
