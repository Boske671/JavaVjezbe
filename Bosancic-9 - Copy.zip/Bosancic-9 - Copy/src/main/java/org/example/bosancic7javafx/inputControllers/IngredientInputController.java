package org.example.bosancic7javafx.inputControllers;

import hr.java.restaurant.model.Category;
import hr.java.restaurant.model.Database;
import hr.java.restaurant.model.Ingredient;
import hr.java.restaurant.repository.CategoriesRepository;
import hr.java.restaurant.repository.IngredientsRepository;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.math.BigDecimal;
import java.sql.SQLException;

public class IngredientInputController
{
    @FXML
    private TextField nameInput;

    @FXML
    private TextField prepMethodInput;

    @FXML
    private TextField kcalInput;

    @FXML
    private ComboBox<Category> categoryComboBox;

    Database database = new Database();

    public void addItem() throws SQLException
    {
        boolean isValid = true;
        StringBuilder errors = new StringBuilder();
        BigDecimal kcal = null;

        // Validate Name
        String name = nameInput.getText().trim();
        if (name.isEmpty()) {
            isValid = false;
            errors.append("Name cannot be empty!\n");
        }

        // Validate Prep Method
        String prepMethod = prepMethodInput.getText().trim();
        if (prepMethod.isEmpty()) {
            isValid = false;
            errors.append("Prep method cannot be empty!\n");
        }

        // Validate Kcal
        try {
            kcal = new BigDecimal(kcalInput.getText().trim());
            if (kcal.compareTo(BigDecimal.ZERO) <= 0) {
                isValid = false;
                errors.append("Kcal must be a positive number!\n");
            }
        } catch (NumberFormatException e) {
            isValid = false;
            errors.append("Kcal must be a valid number!\n");
        }

        // Validate Category
        Category category = categoryComboBox.getSelectionModel().getSelectedItem();
        if (category == null) {
            isValid = false;
            errors.append("Category must be selected!\n");
        }

        // Display Errors or Proceed
        if (!isValid) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("Invalid Ingredient Details");
            alert.setContentText(errors.toString());
            alert.showAndWait();
        } else {
            Ingredient ingredient = new Ingredient(0l, name, category, kcal, prepMethod);
            database.addIngredient(ingredient);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Ingredient added successfully!");
            alert.showAndWait();

            clearInputs();
        }
    }

    private void clearInputs() {
        nameInput.clear();
        prepMethodInput.clear();
        kcalInput.clear();
        categoryComboBox.getSelectionModel().select(0);
    }

    public void displayCombobox() throws SQLException
    {
        categoryComboBox.getItems().addAll(database.getAllCategories());
        categoryComboBox.getSelectionModel().select(0);
    }

    public void initialize() throws SQLException
    {
        displayCombobox();
    }
}
