package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Chef;
import hr.java.restaurant.model.Database;
import hr.java.restaurant.repository.ChefsRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;
import java.util.List;

public class ChefsSearchController
{

    @FXML
    private TextField chefsNameInput;

    @FXML
    private TextField chefsLastNameInput;

    @FXML
    private TableView<Chef> chefsTableView;

    @FXML
    private TableColumn<Chef, Long> chefsIdColumn;

    @FXML
    private TableColumn<Chef, String> chefsNameColumn;

    @FXML
    private TableColumn<Chef, String> chefsLastNameColumn;

    @FXML
    private TableColumn<Chef, String> chefsContractTypeColumn;

    Database db = new Database();

    public void outputChefsToTable() throws SQLException
    {
        List<Chef> chefs = db.getAllChefs();
        ObservableList<Chef> observableChefs = FXCollections.observableArrayList(chefs);
        chefsIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        chefsNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        chefsLastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        chefsContractTypeColumn.setCellValueFactory(cellData ->
        {
            Chef chef = cellData.getValue();
            String contractType = String.valueOf(chef.getContract().getContractType());
            return new SimpleStringProperty(contractType);
        });
        chefsTableView.setItems(observableChefs);
    }

    @FXML
    public void filterChefs() throws SQLException
    {
        ObservableList<Chef> observableChefs = FXCollections.observableArrayList(db.getAllChefs());
        if (chefsNameInput != null && !chefsNameInput.getText().isEmpty())
        {
            String filterText = chefsNameInput.getText().toLowerCase();
            observableChefs = FXCollections.observableArrayList(
                    observableChefs.stream()
                            .filter(chef -> chef.getFirstName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        if (chefsLastNameInput != null && !chefsLastNameInput.getText().isEmpty())
        {
            String filterText = chefsLastNameInput.getText().toLowerCase();
            observableChefs = FXCollections.observableArrayList(
                    observableChefs.stream()
                            .filter(chef -> chef.getLastName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        chefsTableView.setItems(observableChefs);
    }

    @FXML
    public void initialize() throws SQLException
    {
        outputChefsToTable();
    }
}
