package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Chef;
import hr.java.restaurant.model.Database;
import hr.java.restaurant.model.Deliverer;
import hr.java.restaurant.repository.DeliverersRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;
import java.util.List;

public class DeliverersSearchController
{
    @FXML
    private TextField deliverersNameInput;

    @FXML
    private TextField deliverersLastNameInput;

    @FXML
    private TableView<Deliverer> deliverersTableView;

    @FXML
    private TableColumn<Deliverer, Long> deliverersIdColumn;

    @FXML
    private TableColumn<Deliverer, String> deliverersNameColumn;

    @FXML
    private TableColumn<Deliverer, String> deliverersLastNameColumn;

    @FXML
    private TableColumn<Deliverer, String> deliverersContractTypeColumn;

    Database db = new Database();

    public void outputdeliverersToTable() throws SQLException
    {
        List<Deliverer> deliverers = db.getAllDeliverers();
        ObservableList<Deliverer> observabledeliverers = FXCollections.observableArrayList(deliverers);
        deliverersIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        deliverersNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        deliverersLastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        deliverersContractTypeColumn.setCellValueFactory(cellData ->
        {
            Deliverer deliverer = cellData.getValue();
            String contractType = String.valueOf(deliverer.getContract().getContractType());
            return new SimpleStringProperty(contractType);
        });
        deliverersTableView.setItems(observabledeliverers);
    }

    @FXML
    public void filterdeliverers() throws SQLException
    {
        ObservableList<Deliverer> observabledeliverers = FXCollections.observableArrayList(db.getAllDeliverers());
        if (deliverersNameInput != null && !deliverersNameInput.getText().isEmpty())
        {
            String filterText = deliverersNameInput.getText().toLowerCase();
            observabledeliverers = FXCollections.observableArrayList(
                    observabledeliverers.stream()
                            .filter(chef -> chef.getFirstName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        if (deliverersLastNameInput != null && !deliverersLastNameInput.getText().isEmpty())
        {
            String filterText = deliverersLastNameInput.getText().toLowerCase();
            observabledeliverers = FXCollections.observableArrayList(
                    observabledeliverers.stream()
                            .filter(chef -> chef.getLastName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        deliverersTableView.setItems(observabledeliverers);
    }

    @FXML
    public void initialize() throws SQLException
    {
        outputdeliverersToTable();
    }
}
