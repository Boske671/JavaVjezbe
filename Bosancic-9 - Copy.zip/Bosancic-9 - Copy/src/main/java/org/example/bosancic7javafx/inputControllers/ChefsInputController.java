package org.example.bosancic7javafx.inputControllers;

import hr.java.restaurant.enumeration.ContractType;
import hr.java.restaurant.model.Bonus;
import hr.java.restaurant.model.Chef;
import hr.java.restaurant.model.Contract;
import hr.java.restaurant.model.Database;
import hr.java.restaurant.repository.ChefsRepository;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;

public class ChefsInputController
{
    @FXML
    private TextField firstNameInput;

    @FXML
    private TextField lastNameInput;

    @FXML
    private TextField salaryInput;

    @FXML
    private DatePicker startDateInput;

    @FXML
    private DatePicker endDateInput;

    @FXML
    private ComboBox<ContractType> contractTypeInput;

    @FXML
    private TextField bonusInput;

    Database db = new Database();

    public void addItem() throws SQLException
    {
        boolean isValid = true;
        StringBuilder errors = new StringBuilder();

        // Validate first name
        String firstName = firstNameInput.getText();
        if (firstName.isEmpty()) {
            isValid = false;
            errors.append("First name cannot be empty.\n");
        }

        // Validate last name
        String lastName = lastNameInput.getText();
        if (lastName.isEmpty()) {
            isValid = false;
            errors.append("Last name cannot be empty.\n");
        }

        // Validate salary
        BigDecimal salary = null;
        try {
            salary = BigDecimal.valueOf(Double.parseDouble(salaryInput.getText()));
            if (salary.compareTo(BigDecimal.ZERO) <= 0) {
                isValid = false;
                errors.append("Salary must be greater than 0.\n");
            }
        } catch (NumberFormatException e) {
            isValid = false;
            errors.append("Invalid salary format.\n");
        }

        // Validate bonus
        Bonus bonus = null;
        try {
            bonus = new Bonus(BigDecimal.valueOf(Double.parseDouble(bonusInput.getText())));
        } catch (NumberFormatException e) {
            isValid = false;
            errors.append("Invalid bonus format.\n");
        }

        // Validate start date
        LocalDate startDate = startDateInput.getValue();
        if (startDate == null) {
            isValid = false;
            errors.append("Start date must be selected.\n");
        }

        // Validate end date
        LocalDate endDate = endDateInput.getValue();
        if (endDate == null) {
            isValid = false;
            errors.append("End date must be selected.\n");
        } else if (startDate != null && endDate.isBefore(startDate)) {
            isValid = false;
            errors.append("End date cannot be before start date.\n");
        }

        // Validate contract type
        ContractType contractType = contractTypeInput.getSelectionModel().getSelectedItem();
        if (contractType == null) {
            isValid = false;
            errors.append("Contract type must be selected.\n");
        }

        if (!isValid) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(errors.toString());
            alert.showAndWait();
        } else {
            Contract contract = new Contract(salary, startDate, endDate, contractType);
            Chef chef = new Chef(0l, firstName, lastName, contract, bonus);
            db.addChef(chef);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Chef added successfully.");
            alert.showAndWait();
        }
    }

    public void displayCombobox()
    {
        for (ContractType type : ContractType.values())
        {
            contractTypeInput.getItems().add(type);
        }
        contractTypeInput.getSelectionModel().select(0);
    }

    public void initialize()
    {
        displayCombobox();
    }
}
