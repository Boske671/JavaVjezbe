package hr.java.restaurant.model;

import hr.java.restaurant.enumeration.ContractType;
import hr.java.restaurant.model.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


public class Database
{
    private Connection connection;

    // a. Metoda za otvaranje veze na bazu podataka
    public void openConnection() throws SQLException
    {
        String url = "jdbc:h2:tcp://localhost/~/baza";
        String username = "fran";
        String password = "fran";
        connection = DriverManager.getConnection(url, username, password);
        System.out.println("Connection established");
    }

    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(Connection connection)
    {
        this.connection = connection;
    }

    // b. Metoda za zatvaranje veze na bazu podataka
    public void closeConnection() throws SQLException
    {
        if (connection != null && !connection.isClosed())
        {
            connection.close();
            System.out.println("Connection closed");
        }
    }

    // Metoda za dodavanje nove kategorije
    public void addCategory(Category category) throws SQLException
    {
        openConnection();
        String query = "INSERT INTO CATEGORY (name, description) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query))
        {
            stmt.setString(1, category.getName());
            stmt.setString(2, category.getDescription());
            stmt.executeUpdate();
        }
        closeConnection();
    }

    // Metoda za dohvat svih kategorija
    public List<Category> getAllCategories() throws SQLException
    {
        openConnection();
        List<Category> categories = new ArrayList<>();
        String query = "SELECT * FROM CATEGORY";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query))
        {
            while (rs.next())
            {
                categories.add(new Category(
                        rs.getLong("id"),
                        rs.getString("name"),
                        rs.getString("description")
                ));
            }
        }
        closeConnection();
        return categories;
    }

    public Category getCategoryById(long id) throws SQLException
    {
        openConnection();
        String query = "SELECT * FROM CATEGORY WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query))
        {
            stmt.setLong(1, id); // Postavi ID kao parametar upita
            try (ResultSet rs = stmt.executeQuery())
            {
                if (rs.next())
                {
                    // Ako je kategorija pronađena, kreiraj objekt Category
                    return new Category(
                            rs.getLong("id"),
                            rs.getString("name"),
                            rs.getString("description")
                    );
                }
            }
        }
        closeConnection();
        return null; // Ako kategorija nije pronađena
    }


    public void addIngredient(Ingredient ingredient) throws SQLException
    {
        openConnection();
        String query = "INSERT INTO INGREDIENT (name, category_id, kcal, preparation_method) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS))
        {
            stmt.setString(1, ingredient.getName());
            stmt.setLong(2, ingredient.getCategory().getId());
            stmt.setBigDecimal(3, ingredient.getKcal());
            stmt.setString(4, ingredient.getPreparationMethod());
            stmt.executeUpdate();

            // Dohvati generirani ID (ako je potrebno)
            try (ResultSet generatedKeys = stmt.getGeneratedKeys())
            {
                if (generatedKeys.next())
                {
                    ingredient.setId(generatedKeys.getLong(1)); // Postavi ID na objekt
                }
            }
        }
        closeConnection();
    }

    public List<Ingredient> getAllIngredients() throws SQLException
    {
        openConnection();
        List<Ingredient> ingredients = new ArrayList<>();
        String query = "SELECT * FROM INGREDIENT";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query))
        {
            while (rs.next())
            {
                Long id = rs.getLong("id");
                String name = rs.getString("name");
                long categoryId = rs.getLong("category_id");
                Category category = getCategoryById(categoryId);
                BigDecimal kcal = rs.getBigDecimal("kcal");
                String preparationMethod = rs.getString("preparation_method");
                ingredients.add(new Ingredient(
                        id, name, category, kcal, preparationMethod
                ));
            }
        }
        closeConnection();
        return ingredients;
    }

    public void addMeal(Meal meal) throws SQLException
    {
        openConnection();
        String query = "INSERT INTO MEAL (name, category_id, price) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS))
        {
            stmt.setString(1, meal.getName());
            stmt.setLong(2, meal.getCategory().getId());
            stmt.setBigDecimal(3, meal.getPrice());
            stmt.executeUpdate();
            // Dohvati generirani ID (ako je potrebno)
            try (ResultSet generatedKeys = stmt.getGeneratedKeys())
            {
                if (generatedKeys.next())
                {
                    long generatedMealId = generatedKeys.getLong(1); // Generirani ID jela
                    meal.setId(generatedMealId);
                }
            }
        }
        for (Ingredient ingredient : meal.getIngredients())
        {
            query = "INSERT INTO MEAL_INGREDIENT (meal_id, ingredient_id) VALUES (?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS))
            {
                stmt.setLong(1, meal.getId());
                stmt.setLong(2, ingredient.getId());
                stmt.executeUpdate();
                try (ResultSet generatedKeys = stmt.getGeneratedKeys())
                {
                    if (generatedKeys.next())
                    {
                        ingredient.setId(generatedKeys.getLong(1));
                    }
                }
            }
        }
        closeConnection();
    }

    public List<Meal> getAllMeals() throws SQLException
    {
        List<Meal> meals = new ArrayList<>();
        openConnection(); // Otvori vezu na bazu

        try
        {
            // Dohvati sva jela iz MEAL tablice
            String query = "SELECT * FROM MEAL";
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery(query))
            {

                while (rs.next())
                {
                    // Kreiraj objekt Meal za svaki redak
                    long mealId = rs.getLong("id");
                    String name = rs.getString("name");
                    long categoryId = rs.getLong("category_id");
                    BigDecimal price = rs.getBigDecimal("price");

                    // Dohvati kategoriju jela
                    Category category = getCategoryById(categoryId);

                    // Dohvati sastojke za ovo jelo
                    HashSet<Ingredient> ingredients = new HashSet<>();
                    String ingredientQuery = "SELECT i.* FROM INGREDIENT i " +
                            "JOIN MEAL_INGREDIENT mi ON i.id = mi.ingredient_id " +
                            "WHERE mi.meal_id = ?";
                    try (PreparedStatement ingredientStmt = connection.prepareStatement(ingredientQuery))
                    {
                        ingredientStmt.setLong(1, mealId);
                        try (ResultSet ingredientRs = ingredientStmt.executeQuery())
                        {
                            while (ingredientRs.next())
                            {
                                Ingredient ingredient = new Ingredient(
                                        ingredientRs.getLong("id"),
                                        ingredientRs.getString("name"),
                                        getCategoryById(ingredientRs.getLong("category_id")),
                                        ingredientRs.getBigDecimal("kcal"),
                                        ingredientRs.getString("preparation_method")
                                );
                                ingredients.add(ingredient);
                            }
                        }
                    }

                    // Kreiraj objekt Meal i dodaj ga u listu
                    Meal meal = new Meal(mealId, name, category, ingredients, price);
                    meals.add(meal);
                }
            }
        } finally
        {
            closeConnection(); // Zatvori vezu
        }

        return meals;
    }

    public void addChef(Chef chef) throws SQLException
    {
        openConnection(); // Otvori vezu na bazu

        String query = "INSERT INTO CHEF (first_name, last_name, salary, start_date, end_date, contract_type, bonus) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS))
        {
            stmt.setString(1, chef.getFirstName());
            stmt.setString(2, chef.getLastName());
            stmt.setBigDecimal(3, chef.getContract().getSalary());
            stmt.setDate(4, Date.valueOf(chef.getContract().getStartDate())); // Pretvori LocalDate u java.sql.Date
            stmt.setDate(5, Date.valueOf(chef.getContract().getEndDate()));   // Pretvori LocalDate u java.sql.Date
            stmt.setString(6, String.valueOf(chef.getContract().getContractType()));
            stmt.setBigDecimal(7, chef.getBonus().bonus());
            stmt.executeUpdate();

            // Dohvati generirani ID (ako je potrebno)
            try (ResultSet generatedKeys = stmt.getGeneratedKeys())
            {
                if (generatedKeys.next())
                {
                    chef.setId(generatedKeys.getLong(1)); // Postavi ID na objekt
                }
            }
        } finally
        {
            closeConnection(); // Zatvori vezu
        }
    }

    public List<Chef> getAllChefs() throws SQLException
    {
        List<Chef> chefs = new ArrayList<>();
        openConnection(); // Otvori vezu na bazu

        try
        {
            String query = "SELECT * FROM CHEF";
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery(query))
            {

                while (rs.next())
                {
                    // Kreiraj objekt Chef za svaki redak
                    long id = rs.getLong("id");
                    String firstName = rs.getString("first_name");
                    String lastName = rs.getString("last_name");
                    BigDecimal salary = rs.getBigDecimal("salary");
                    LocalDate startDate = rs.getDate("start_date").toLocalDate(); // Pretvori java.sql.Date u LocalDate
                    LocalDate endDate = rs.getDate("end_date").toLocalDate();     // Pretvori java.sql.Date u LocalDate
                    String contractType = rs.getString("contract_type");
                    BigDecimal bonus = rs.getBigDecimal("bonus");
                    Chef chef = new Chef(id, firstName, lastName, new Contract(salary, startDate, endDate, ContractType.valueOf(contractType)), new Bonus(bonus));
                    chefs.add(chef);
                }
            }
        } finally
        {
            closeConnection(); // Zatvori vezu
        }

        return chefs;
    }

    public void addWaiter(Waiter waiter) throws SQLException
    {
        openConnection(); // Otvori vezu na bazu

        String query = "INSERT INTO WAITER (first_name, last_name, salary, start_date, end_date, contract_type, bonus) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS))
        {
            stmt.setString(1, waiter.getFirstName());
            stmt.setString(2, waiter.getLastName());
            stmt.setBigDecimal(3, waiter.getContract().getSalary());
            stmt.setDate(4, Date.valueOf(waiter.getContract().getStartDate())); // Pretvori LocalDate u java.sql.Date
            stmt.setDate(5, Date.valueOf(waiter.getContract().getEndDate()));   // Pretvori LocalDate u java.sql.Date
            stmt.setString(6, String.valueOf(waiter.getContract().getContractType()));
            stmt.setBigDecimal(7, waiter.getBonus().bonus());
            stmt.executeUpdate();

            // Dohvati generirani ID (ako je potrebno)
            try (ResultSet generatedKeys = stmt.getGeneratedKeys())
            {
                if (generatedKeys.next())
                {
                    waiter.setId(generatedKeys.getLong(1)); // Postavi ID na objekt
                }
            }
        } finally
        {
            closeConnection(); // Zatvori vezu
        }
    }

    public List<Waiter> getAllWaiters() throws SQLException
    {
        List<Waiter> waiters = new ArrayList<>();
        openConnection(); // Otvori vezu na bazu

        try
        {
            String query = "SELECT * FROM WAITER";
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery(query))
            {

                while (rs.next())
                {
                    // Kreiraj objekt Waiter za svaki redak
                    long id = rs.getLong("id");
                    String firstName = rs.getString("first_name");
                    String lastName = rs.getString("last_name");
                    BigDecimal salary = rs.getBigDecimal("salary");
                    LocalDate startDate = rs.getDate("start_date").toLocalDate(); // Pretvori java.sql.Date u LocalDate
                    LocalDate endDate = rs.getDate("end_date").toLocalDate();     // Pretvori java.sql.Date u LocalDate
                    String contractType = rs.getString("contract_type");
                    BigDecimal bonus = rs.getBigDecimal("bonus");
                    Waiter waiter = new Waiter(id, firstName, lastName, new Contract(salary, startDate, endDate, ContractType.valueOf(contractType)), new Bonus(bonus));
                    waiters.add(waiter);
                }
            }
        } finally
        {
            closeConnection(); // Zatvori vezu
        }

        return waiters;
    }

    public void addDeliverer(Deliverer deliverer) throws SQLException
    {
        openConnection(); // Otvori vezu na bazu

        String query = "INSERT INTO DELIVERER (first_name, last_name, salary, start_date, end_date, contract_type, bonus) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS))
        {
            stmt.setString(1, deliverer.getFirstName());
            stmt.setString(2, deliverer.getLastName());
            stmt.setBigDecimal(3, deliverer.getContract().getSalary());
            stmt.setDate(4, Date.valueOf(deliverer.getContract().getStartDate())); // Pretvori LocalDate u java.sql.Date
            stmt.setDate(5, Date.valueOf(deliverer.getContract().getEndDate()));   // Pretvori LocalDate u java.sql.Date
            stmt.setString(6, String.valueOf(deliverer.getContract().getContractType()));
            stmt.setBigDecimal(7, deliverer.getBonus().bonus());
            stmt.executeUpdate();

            // Dohvati generirani ID (ako je potrebno)
            try (ResultSet generatedKeys = stmt.getGeneratedKeys())
            {
                if (generatedKeys.next())
                {
                    deliverer.setId(generatedKeys.getLong(1)); // Postavi ID na objekt
                }
            }
        } finally
        {
            closeConnection(); // Zatvori vezu
        }
    }

    public List<Deliverer> getAllDeliverers() throws SQLException
    {
        List<Deliverer> deliverers = new ArrayList<>();
        openConnection(); // Otvori vezu na bazu

        try
        {
            String query = "SELECT * FROM DELIVERER";
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery(query))
            {

                while (rs.next())
                {
                    // Kreiraj objekt Deliverer za svaki redak
                    long id = rs.getLong("id");
                    String firstName = rs.getString("first_name");
                    String lastName = rs.getString("last_name");
                    BigDecimal salary = rs.getBigDecimal("salary");
                    LocalDate startDate = rs.getDate("start_date").toLocalDate(); // Pretvori java.sql.Date u LocalDate
                    LocalDate endDate = rs.getDate("end_date").toLocalDate();     // Pretvori java.sql.Date u LocalDate
                    String contractType = rs.getString("contract_type");
                    BigDecimal bonus = rs.getBigDecimal("bonus");
                    Deliverer deliverer = new Deliverer(id, firstName, lastName, new Contract(salary, startDate, endDate, ContractType.valueOf(contractType)), new Bonus(bonus));
                    deliverers.add(deliverer);
                }
            }
        } finally
        {
            closeConnection(); // Zatvori vezu
        }

        return deliverers;
    }


    public List<Restaurant> findAllRestaurants() throws SQLException
    {
        String url = "jdbc:h2:tcp://localhost/~/baza";
        String username = "fran";
        String password = "fran";
        List<Restaurant> restaurants = new ArrayList<>();
        openConnection();
        connection = DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();
        String query = "SELECT * FROM RESTAURANT";
        ResultSet rs = statement.executeQuery(query);
        while (rs.next())
        {
            Long id = rs.getLong("id");
            String name = rs.getString("name");
            String street = rs.getString("street");
            String houseNumber = rs.getString("houseNumber");
            String city = rs.getString("city");
            String postalCode = rs.getString("postal_code");
            Address address = new Address(0L, street, houseNumber, city, postalCode);

            HashSet<Meal> meals = new HashSet<>();
            String query2 = "SELECT * FROM RESTAURANT_MEAL WHERE restaurant_id = " + id;
            openConnection();
            Statement stmt2 = connection.createStatement();
            ResultSet resultSetMeals = stmt2.executeQuery(query2);
            while (resultSetMeals.next())
            {
                Long mealId = resultSetMeals.getLong("meal_id");
                Meal meal = findMealById(mealId);
                meals.add(meal);
            }

            HashSet<Waiter> waiters = new HashSet<>();
            openConnection();
            Statement stmt3 = connection.createStatement();
            String query3 = "SELECT * FROM RESTAURANT_WAITER WHERE restaurant_id = " + id;
            ResultSet resultSetWaiters = stmt3.executeQuery(query3);
            while (resultSetWaiters.next())
            {
                Long waiterId = resultSetWaiters.getLong("waiter_id");
                Waiter waiter = findWaiterById(waiterId);
                waiters.add(waiter);
            }

            HashSet<Chef> chefs = new HashSet<>();
            openConnection();
            Statement stmt4 = connection.createStatement();
            String query4 = "SELECT * FROM RESTAURANT_CHEF WHERE restaurant_id = " + id;
            ResultSet resultSetChefs = stmt4.executeQuery(query4);
            while (resultSetChefs.next())
            {
                Long chefId = resultSetChefs.getLong("chef_id");
                Chef chef = findChefById(chefId);
                chefs.add(chef);
            }

            HashSet<Deliverer> deliverers = new HashSet<>();
            openConnection();
            Statement stmt5 = connection.createStatement();
            String query5 = "SELECT * FROM RESTAURANT_DELIVERER WHERE restaurant_id = " + id;
            ResultSet resultSetDeliverers = stmt5.executeQuery(query5);
            while (resultSetDeliverers.next())
            {
                Long delivererId = resultSetDeliverers.getLong("deliverer_id");
                Deliverer deliverer = findDelivererById(delivererId);
                deliverers.add(deliverer);
            }
            Restaurant restaurant = new Restaurant(id, name, address, meals, chefs, waiters, deliverers);
            restaurants.add(restaurant);
        }
        connection.close();
        return restaurants;
    }

    public void addRestaurant(Restaurant restaurant) throws SQLException
    {
        openConnection(); // Otvori vezu na bazu

        try
        {
            // Dodaj restoran u RESTAURANT tablicu
            String restaurantQuery = "INSERT INTO RESTAURANT (NAME, STREET, HOUSENUMBER, CITY, POSTAL_CODE) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement restaurantStmt = connection.prepareStatement(restaurantQuery, Statement.RETURN_GENERATED_KEYS))
            {
                restaurantStmt.setString(1, restaurant.getName());
                restaurantStmt.setString(2, restaurant.getAddress().getStreet());
                restaurantStmt.setString(3, restaurant.getAddress().getHouseNumber());
                restaurantStmt.setString(4, restaurant.getAddress().getCity());
                restaurantStmt.setString(5, restaurant.getAddress().getPostalCode());
                restaurantStmt.executeUpdate();

                // Dohvati generirani ID restorana
                try (ResultSet generatedKeys = restaurantStmt.getGeneratedKeys())
                {
                    if (generatedKeys.next())
                    {
                        long restaurantId = generatedKeys.getLong(1);
                        restaurant.setId(restaurantId);
                    }
                }
            }

            // Dodaj veze između restorana i jela u RESTAURANT_MEAL tablicu
            for (Meal meal : restaurant.getMeals())
            {
                String mealQuery = "INSERT INTO RESTAURANT_MEAL (RESTAURANT_ID, MEAL_ID) VALUES (?, ?)";
                try (PreparedStatement mealStmt = connection.prepareStatement(mealQuery))
                {
                    mealStmt.setLong(1, restaurant.getId());
                    mealStmt.setLong(2, meal.getId());
                    mealStmt.executeUpdate();
                }
            }

            // Dodaj veze između restorana i konobara u RESTAURANT_WAITER tablicu
            for (Waiter waiter : restaurant.getWaiters())
            {
                String waiterQuery = "INSERT INTO RESTAURANT_WAITER (RESTAURANT_ID, WAITER_ID) VALUES (?, ?)";
                try (PreparedStatement waiterStmt = connection.prepareStatement(waiterQuery))
                {
                    waiterStmt.setLong(1, restaurant.getId());
                    waiterStmt.setLong(2, waiter.getId());
                    waiterStmt.executeUpdate();
                }
            }

            // Dodaj veze između restorana i kuhara u RESTAURANT_CHEF tablicu
            for (Chef chef : restaurant.getChefs())
            {
                String chefQuery = "INSERT INTO RESTAURANT_CHEF (RESTAURANT_ID, CHEF_ID) VALUES (?, ?)";
                try (PreparedStatement chefStmt = connection.prepareStatement(chefQuery))
                {
                    chefStmt.setLong(1, restaurant.getId());
                    chefStmt.setLong(2, chef.getId());
                    chefStmt.executeUpdate();
                }
            }

            // Dodaj veze između restorana i dostavljača u RESTAURANT_DELIVERER tablicu
            for (Deliverer deliverer : restaurant.getDeliverers())
            {
                String delivererQuery = "INSERT INTO RESTAURANT_DELIVERER (RESTAURANT_ID, DELIVERER_ID) VALUES (?, ?)";
                try (PreparedStatement delivererStmt = connection.prepareStatement(delivererQuery))
                {
                    delivererStmt.setLong(1, restaurant.getId());
                    delivererStmt.setLong(2, deliverer.getId());
                    delivererStmt.executeUpdate();
                }
            }
        } finally
        {
            closeConnection(); // Zatvori vezu
        }
    }

    public Category findCategoryById(Long id) throws SQLException
    {
        return getAllCategories().stream()
                .filter(category -> category.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Ingredient findIngredientById(Long id) throws SQLException
    {
        return getAllIngredients().stream()
                .filter(ingredient -> ingredient.getId().equals(id))
                .findFirst()
                .orElse(null);
    }


    public Meal findMealById(Long id) throws SQLException
    {
        return getAllMeals().stream()
                .filter(meal -> meal.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Waiter findWaiterById(Long id) throws SQLException
    {
        return getAllWaiters().stream()
                .filter(waiter -> waiter.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Chef findChefById(Long id) throws SQLException
    {
        return getAllChefs().stream()
                .filter(chef -> chef.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Deliverer findDelivererById(Long id) throws SQLException
    {
        return getAllDeliverers().stream()
                .filter(deliverer -> deliverer.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Restaurant findRestaurantById(Long id) throws SQLException
    {
        return findAllRestaurants().stream()
                .filter(restaurant -> restaurant.getId().equals(id))
                .findFirst()
                .orElse(null);
    }


    public List<Order> findAllOrders() throws SQLException
    {
        List<Order> orders = new ArrayList<>();
        openConnection();
        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery("SELECT * FROM ORDERS");
        while (resultSet.next())
        {
            Long id = resultSet.getLong("id");
            Long restaurantId = resultSet.getLong("restaurant_id");
            Long delivererId = resultSet.getLong("deliverer_id");
            LocalDateTime deliveryDateAndTime = LocalDateTime.from(resultSet.getTimestamp("date").toLocalDateTime());

            Restaurant restaurant = findRestaurantById(restaurantId);
            Deliverer deliverer = findDelivererById(delivererId);

            ArrayList<Meal> meals = new ArrayList<>();
            openConnection();
            try (Statement statementMeals = connection.createStatement();)
            {
                ResultSet resultSetMeals = statementMeals.executeQuery("SELECT * FROM ORDER_MEAL WHERE orders_id = " + id);
                while (resultSetMeals.next())
                {
                    Long mealId = resultSetMeals.getLong("meal_id");
                    Meal meal = findMealById(mealId);
                    meals.add(meal);
                }
            }

            Order order = new Order(id, restaurant, meals, deliverer, deliveryDateAndTime);
            orders.add(order);
        }
        closeConnection();
        return orders;
    }

    public void saveOrder(Order order) throws SQLException {
        openConnection(); // Otvori vezu na bazu

        try {
            // Dodaj narudžbu u ORDERS tablicu
            String query = "INSERT INTO ORDERS (restaurant_id, deliverer_id, date) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setLong(1, order.getRestaurant().getId());
                preparedStatement.setLong(2, order.getDeliverer().getId());
                preparedStatement.setTimestamp(3, Timestamp.valueOf(order.getDeliveryDateAndTime())); // Correct conversion
                preparedStatement.executeUpdate();

                // Dohvati generirani ID narudžbe
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        Long generatedId = generatedKeys.getLong(1);
                        order.setId(generatedId);
                    }
                }
            }

            // Dodaj veze između narudžbe i jela u ORDER_MEAL tablicu
            String mealQuery = "INSERT INTO ORDER_MEAL (orders_id, meal_id) VALUES (?, ?)";
            try (PreparedStatement preparedStatementMeals = connection.prepareStatement(mealQuery)) {
                for (Meal meal : order.getMeals()) {
                    preparedStatementMeals.setLong(1, order.getId());
                    preparedStatementMeals.setLong(2, meal.getId());
                    preparedStatementMeals.executeUpdate();
                }
            }
        } finally {
            closeConnection(); // Zatvori vezu
        }
    }

    public List<Restaurant> findAllRestaurants2() throws SQLException
    {
        String url = "jdbc:h2:tcp://localhost/~/baza";
        String username = "fran";
        String password = "fran";
        List<Restaurant> restaurants = new ArrayList<>();
        connection = DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();
        String query = "SELECT * FROM RESTAURANT";
        ResultSet rs = statement.executeQuery(query);
        while (rs.next())
        {
            Long id = rs.getLong("id");
            String name = rs.getString("name");
            String street = rs.getString("street");
            String houseNumber = rs.getString("houseNumber");
            String city = rs.getString("city");
            String postalCode = rs.getString("postal_code");
            Address address = new Address(0L, street, houseNumber, city, postalCode);

            HashSet<Meal> meals = new HashSet<>();
            String query2 = "SELECT * FROM RESTAURANT_MEAL WHERE restaurant_id = " + id;
            ResultSet resultSetMeals = statement.executeQuery(query2);
            while (resultSetMeals.next())
            {
                Long mealId = resultSetMeals.getLong("meal_id");
                Meal meal = findMealById(mealId);
                meals.add(meal);
            }

            HashSet<Waiter> waiters = new HashSet<>();
            String query3 = "SELECT * FROM WAITER WHERE restaurant_id = " + id;
            ResultSet resultSetWaiters = statement.executeQuery(query3);
            while (resultSetWaiters.next())
            {
                Long waiterId = resultSetWaiters.getLong("waiter_id");
                Waiter waiter = findWaiterById(waiterId);
                waiters.add(waiter);
            }

            HashSet<Chef> chefs = new HashSet<>();
            String query4 = "SELECT * FROM CHEF WHERE restaurant_id = " + id;
            ResultSet resultSetChefs = statement.executeQuery(query4);
            while (resultSetChefs.next())
            {
                Long chefId = resultSetChefs.getLong("chef_id");
                Chef chef = findChefById(chefId);
                chefs.add(chef);
            }

            HashSet<Deliverer> deliverers = new HashSet<>();
            String query5 = "SELECT * FROM DELIVERER WHERE restaurant_id = " + id;
            ResultSet resultSetDeliverers = statement.executeQuery(query5);
            while (resultSetDeliverers.next())
            {
                Long delivererId = resultSetDeliverers.getLong("deliverer_id");
                Deliverer deliverer = findDelivererById(delivererId);
                deliverers.add(deliverer);
            }
            Restaurant restaurant = new Restaurant(id, name, address, meals, chefs, waiters, deliverers);
            restaurants.add(restaurant);
        }
        connection.close();
        return restaurants;
    }

    public void deleteCategory(Category category) throws SQLException
    {
        openConnection();
        Statement statement = connection.createStatement();
        String query = "DELETE FROM CATEGORY WHERE id = " + category.getId();
        statement.executeUpdate(query);
        closeConnection();
    }


    public void updateCategory(Category category) throws SQLException {
        openConnection();
        String query = "UPDATE CATEGORY SET name = ?, description = ? WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, category.getName());
            pstmt.setString(2, category.getDescription());
            pstmt.setLong(3, category.getId());
            pstmt.executeUpdate();
        } finally {
            closeConnection();
        }
    }
}
