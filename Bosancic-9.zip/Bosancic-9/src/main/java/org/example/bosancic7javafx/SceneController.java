package org.example.bosancic7javafx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;

import java.io.IOException;

public class SceneController {


    // Root layout in MainFXML
    @FXML
    private BorderPane rootPane;
    
    @FXML
    private void categoriesMenuItemAction(ActionEvent event) throws IOException {
        loadScene("CategoriesSearch.fxml");
    }
    
    @FXML
    private void ingredientsMenuItemAction(ActionEvent event) throws IOException {
        loadScene("IngredientsSearch.fxml");
    }
    
    @FXML
    private void mealsMenuItemAction(ActionEvent event) throws IOException {
        loadScene("MealsSearch.fxml");
    }
    
    @FXML
    private void chefsMenuItemAction(ActionEvent event) throws IOException {
        loadScene("ChefsSearch.fxml");
    }
    
    @FXML
    private void deliverersMenuItemAction(ActionEvent event) throws IOException {
        loadScene("DeliverersSearch.fxml");
    }

    @FXML
    private void waitersMenuItemAction(ActionEvent event) throws IOException {
        loadScene("WaitersSearch.fxml");
    }
    
    @FXML
    private void restaurantsMenuItemAction(ActionEvent event) throws IOException {
        loadScene("RestaurantsSearch.fxml");
    }
    
    @FXML
    private void ordersMenuItemAction(ActionEvent event) throws IOException {
        loadScene("OrdersSearch.fxml");
    }

    @FXML
    private void categoriesInputMenuItemAction(ActionEvent event) throws IOException {
        loadScene("CategoriesInput.fxml");
    }

    @FXML
    private void ingredientsInputMenuItemAction(ActionEvent event) throws IOException {
        loadScene("IngredientInput.fxml");
    }

    @FXML
    private void mealsInputMenuItemAction(ActionEvent event) throws IOException {
        loadScene("MealsInput.fxml");
    }

    @FXML
    private void chefsInputMenuItemAction(ActionEvent event) throws IOException {
        loadScene("ChefsInput.fxml");
    }

    @FXML
    private void deliverersInputMenuItemAction(ActionEvent event) throws IOException {
        loadScene("DeliverersInput.fxml");
    }

    @FXML
    private void waitersInputMenuItemAction(ActionEvent event) throws IOException {
        loadScene("WaitersInput.fxml");
    }

    @FXML
    private void restaurantsInputMenuItemAction(ActionEvent event) throws IOException {
        loadScene("RestaurantsInput.fxml");
    }

    @FXML
    private void ordersInputMenuItemAction(ActionEvent event) throws IOException {
        loadScene("OrdersInput.fxml");
    }
    // Generic method to load a scene
    private void loadScene(String fxmlPath) throws IOException {
        // Load the new FXML file
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Parent newContent = loader.load();
        // Replace the center content of the BorderPane
        rootPane.setCenter(newContent);
    }
}