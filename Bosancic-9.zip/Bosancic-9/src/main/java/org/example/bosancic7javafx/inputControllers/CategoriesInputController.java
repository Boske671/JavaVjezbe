package org.example.bosancic7javafx.inputControllers;

import hr.java.restaurant.model.Category;
import hr.java.restaurant.model.Database;
import hr.java.restaurant.repository.CategoriesRepository;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class CategoriesInputController
{
    @FXML
    private TextField nameInput;

    @FXML
    private TextField descriptionInput;

    private Database database = new Database();

    public void addItem(ActionEvent event) throws SQLException
    {
        boolean isValid = true;
        StringBuilder errors = new StringBuilder();

        // Retrieve and validate inputs
        String name = nameInput.getText().trim();
        String description = descriptionInput.getText().trim();

        if (name.isEmpty()) {
            isValid = false;
            errors.append("Name cannot be empty.\n");
        }
        if (description.isEmpty()) {
            isValid = false;
            errors.append("Description cannot be empty.\n");
        }

        // Display errors or proceed
        if (!isValid) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("Invalid Category Details");
            alert.setContentText(errors.toString());
            alert.showAndWait();
        } else {
            Category category = new Category(-1l, name, description);
            database.addCategory(category);

            // Success alert
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Category added successfully!");
            alert.showAndWait();

            clearInputs();
        }
    }

    private void clearInputs() {
        nameInput.clear();
        descriptionInput.clear();
    }
}
