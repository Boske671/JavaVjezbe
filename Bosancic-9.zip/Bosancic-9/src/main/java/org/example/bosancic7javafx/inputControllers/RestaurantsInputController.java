package org.example.bosancic7javafx.inputControllers;

import hr.java.restaurant.model.*;
import hr.java.restaurant.repository.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.sql.SQLException;
import java.util.HashSet;

public class RestaurantsInputController
{
    @FXML
    private TextField restaurantNameInput;
    @FXML
    private TextField restaurantStreetInput;
    @FXML
    private TextField restaurantHouseNumberInput;
    @FXML
    private TextField restaurantCityInput;
    @FXML
    private TextField restaurantPostalCodeInput;

    @FXML
    private ComboBox<Meal> restaurantMealsComboBox;
    @FXML
    private ComboBox<Chef> restaurantChefsComboBox;
    @FXML
    private ComboBox<Waiter> restaurantWaitersComboBox;
    @FXML
    private ComboBox<Deliverer> restaurantDeliverersComboBox;



    Database db = new Database();

    HashSet<Meal> meals = new HashSet<>();
    HashSet<Chef> chefs = new HashSet<>();
    HashSet<Waiter> waiters = new HashSet<>();
    HashSet<Deliverer> deliverers = new HashSet<>();

    public void addItem() throws SQLException
    {
        boolean isValid = true;
        StringBuilder errors = new StringBuilder();

        String restaurantName = restaurantNameInput.getText();
        if (restaurantName.isEmpty()) {
            isValid = false;
            errors.append("Restaurant name cannot be empty.\n");
        }

        String restaurantStreet = restaurantStreetInput.getText();
        if (restaurantStreet.isEmpty()) {
            isValid = false;
            errors.append("Street cannot be empty.\n");
        }

        String restaurantHouseNumber = restaurantHouseNumberInput.getText();
        if (restaurantHouseNumber.isEmpty()) {
            isValid = false;
            errors.append("House number cannot be empty.\n");
        }

        String restaurantCity = restaurantCityInput.getText();
        if (restaurantCity.isEmpty()) {
            isValid = false;
            errors.append("City cannot be empty.\n");
        }

        String restaurantPostalCode = restaurantPostalCodeInput.getText();
        if (restaurantPostalCode.isEmpty()) {
            isValid = false;
            errors.append("Postal code cannot be empty.\n");
        }

        if (meals.isEmpty()) {
            isValid = false;
            errors.append("At least one meal must be added.\n");
        }

        if (chefs.isEmpty()) {
            isValid = false;
            errors.append("At least one chef must be added.\n");
        }

        if (waiters.isEmpty()) {
            isValid = false;
            errors.append("At least one waiter must be added.\n");
        }

        if (deliverers.isEmpty()) {
            isValid = false;
            errors.append("At least one deliverer must be added.\n");
        }

        if (!isValid) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(errors.toString());
            alert.showAndWait();
        } else {
            Address address = new Address(0l, restaurantStreet, restaurantHouseNumber, restaurantCity, restaurantPostalCode);
            Restaurant restaurant = new Restaurant(0l, restaurantName, address, meals, chefs, waiters, deliverers);
            db.addRestaurant(restaurant);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Restaurant added successfully.");
            alert.showAndWait();

            clearHashSets();
        }
    }

    public void displayCombobox() throws SQLException
    {
        for (Meal meal : db.getAllMeals())
        {
            restaurantMealsComboBox.getItems().add(meal);
        }
        restaurantMealsComboBox.getSelectionModel().select(0);
        for (Chef chef : db.getAllChefs())
        {
            restaurantChefsComboBox.getItems().add(chef);
        }
        restaurantChefsComboBox.getSelectionModel().select(0);
        for (Waiter waiter : db.getAllWaiters())
        {
            restaurantWaitersComboBox.getItems().add(waiter);
        }
        restaurantWaitersComboBox.getSelectionModel().select(0);
        for (Deliverer deliverer : db.getAllDeliverers())
        {
            restaurantDeliverersComboBox.getItems().add(deliverer);
        }
        restaurantDeliverersComboBox.getSelectionModel().select(0);
    }

    public void addMeal(ActionEvent event) {
        Meal meal = restaurantMealsComboBox.getSelectionModel().getSelectedItem();
        if (meal != null) {
            meals.add(meal);
        }
    }

    public void addChef(ActionEvent event)
    {
        Chef chef = restaurantChefsComboBox.getSelectionModel().getSelectedItem();
        if (chef != null) {
            chefs.add(chef);
        }
    }

    public void addDeliverer(ActionEvent event)
    {
        Deliverer deliverer = restaurantDeliverersComboBox.getSelectionModel().getSelectedItem();
        if (deliverer != null) {
            deliverers.add(deliverer);
        }
    }

    public void addWaiter(ActionEvent event)
    {
        Waiter waiter = restaurantWaitersComboBox.getSelectionModel().getSelectedItem();
        if (waiter != null) {
            waiters.add(waiter);
        }
    }

    public void clearHashSets()
    {
        meals.clear();
        chefs.clear();
        deliverers.clear();
        waiters.clear();
    }

    public void initialize() throws SQLException
    {
        displayCombobox();
    }
}
