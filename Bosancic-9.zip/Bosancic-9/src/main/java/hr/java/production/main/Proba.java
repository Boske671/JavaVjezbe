package hr.java.production.main;

import hr.java.restaurant.model.Database;

import java.sql.SQLException;

public class Proba
{
    public static void main(String[] args) throws SQLException
    {
        Database database = new Database();
        database.openConnection();


    }
}
