package hr.java.production.main;

import hr.java.restaurant.model.*;
import hr.java.restaurant.repository.*;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileInputOutput {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        List<Category> categories = new ArrayList<Category>();
        CategoriesRepository categoriesRepository = new CategoriesRepository();
        categories = categoriesRepository.readFromFile();
        for (Category category : categories) {
            category.ispisCategory();
        }
        System.out.println();

        IngredientsRepository ingredientsRepository = new IngredientsRepository();
        List<Ingredient> ingredients = ingredientsRepository.readFromFile();
        for (Ingredient ingredient : ingredients) {
            ingredient.ispisIngredient();
        }
        System.out.println();

        MealsRepository mealsRepository = new MealsRepository();
        List<Meal> meals = mealsRepository.readFromFile();
        for (Meal meal : meals) {
            meal.ispisMeal();
        }
        System.out.println();

        ChefsRepository chefsRepository = new ChefsRepository();
        List<Chef> chefs = chefsRepository.readFromFile();
        for (Chef chef : chefs) {
            chef.ispisZaposlenik();
        }
        System.out.println();

        DeliverersRepository deliverersRepository = new DeliverersRepository();
        List<Deliverer> deliverers = deliverersRepository.readFromFile();
        for (Deliverer deliverer : deliverers) {
            deliverer.ispisZaposlenik();
        }
        System.out.println();

        WaitersRepository waitersRepository = new WaitersRepository();
        List<Waiter> waiters = waitersRepository.readFromFile();
        for (Waiter waiter : waiters) {
            waiter.ispisZaposlenik();
        }
        System.out.println();
        RestaurantRepository restaurantRepository = new RestaurantRepository();
        List<Restaurant> restaurants = restaurantRepository.readFromFile();
        for (Restaurant restaurant : restaurants) {
            restaurant.ispisRestoran();
        }
        System.out.println();


        OrdersRepository ordersRepository = new OrdersRepository();
        List<Order> orders = ordersRepository.readFromFile();
        for (Order order : orders) {
            order.ispisOrder();
        }


        System.out.println("-------------------------------------\n \t\t\tBINARY \n-------------------------------------\n");
        categoriesRepository.writeListToBinaryFile(categories);
        List<Category> categories2 = categoriesRepository.readFromFile();
        for (Category category : categories2) {
            category.ispisCategory();
        }
        System.out.println();


        ingredientsRepository.writeListToBinaryFile(ingredients);
        List<Ingredient> ingredients2 = ingredientsRepository.readFromFile();
        for (Ingredient ingredient : ingredients) {
            ingredient.ispisIngredient();
        }
        System.out.println();


        mealsRepository.writeListToBinaryFile(meals);
        List<Meal> meals2 = mealsRepository.readFromFile();
        for (Meal meal : meals) {
            meal.ispisMeal();
        }
        System.out.println();


        chefsRepository.writeListToBinaryFile(chefs);
        List<Chef> chefs2 = chefsRepository.readFromFile();
        for (Chef chef : chefs) {
            chef.ispisZaposlenik();
        }
        System.out.println();


        deliverersRepository.writeListToBinaryFile(deliverers);
        List<Deliverer> deliverers2 = deliverersRepository.readFromFile();
        for (Deliverer deliverer : deliverers) {
            deliverer.ispisZaposlenik();
        }
        System.out.println();


        waitersRepository.writeListToBinaryFile(waiters);
        List<Waiter> waiters2 = waitersRepository.readFromFile();
        for (Waiter waiter : waiters) {
            waiter.ispisZaposlenik();
        }
        System.out.println();


        restaurantRepository.writeListToBinaryFile(restaurants);
        List<Restaurant> restaurants2 = restaurantRepository.readFromFile();
        for (Restaurant restaurant : restaurants) {
            restaurant.ispisRestoran();
        }
        System.out.println();


        ordersRepository.writeListToBinaryFile(orders);
        List<Order> orders2 = ordersRepository.readFromFile();
        for (Order order : orders) {
            order.ispisOrder();
        }
    }
}
