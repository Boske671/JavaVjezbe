package hr.java.restaurant.enumeration;

public enum ContractType {
    FULL_TIME,
    PART_TIME
}
