package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Chef;
import hr.java.restaurant.model.Restaurant;
import hr.java.restaurant.repository.RestaurantRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;
import java.util.stream.Collectors;

public class RestaurantsSearchController
{
    @FXML
    private TextField restaurantNameInput;

    @FXML
    private TextField addressNameInput;

    @FXML
    private TableView<Restaurant> restaurantTable;

    @FXML
    private TableColumn<Restaurant, Long> restaurantIDColumn;

    @FXML
    private TableColumn<Restaurant, String> restaurantNameColumn;

    @FXML
    private TableColumn<Restaurant, String> addressNameColumn;

    @FXML
    private TableColumn<Restaurant, String> mealsIDsColumn;

    @FXML
    private TableColumn<Restaurant, String> deliverersIDsColumn;

    @FXML
    private TableColumn<Restaurant, String> chefsIDsColumn;

    @FXML
    private TableColumn<Restaurant, String> waitersIDsColumn;

    @FXML
    private Button filterButton;

    RestaurantRepository restaurantRepository = new RestaurantRepository();

    public void outputRestaurantsToTable()
    {
        List<Restaurant> restaurants = restaurantRepository.readFromFile();
        ObservableList<Restaurant> restaurantObservableList = FXCollections.observableList(restaurants);
        restaurantIDColumn.setCellValueFactory(new PropertyValueFactory<Restaurant, Long>("id"));
        restaurantNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        addressNameColumn.setCellValueFactory(data ->
        {
            Restaurant restaurant = data.getValue();
            return new SimpleStringProperty(restaurant.getAddress().getStreet());
        });
        mealsIDsColumn.setCellValueFactory(data ->
        {
            Restaurant restaurant = data.getValue();
            String mealIDs = restaurant.getMeals()
                .stream()
                .map(meal -> Long.toString(meal.getId())) // Convert long to String
                .collect(Collectors.joining(", "));
            return new SimpleStringProperty(mealIDs);
        });

        deliverersIDsColumn.setCellValueFactory(data ->
        {
            Restaurant restaurant = data.getValue();
            String deliverersIDs = restaurant.getDeliverers()
                    .stream()
                    .map(deliverer -> Long.toString(deliverer.getId())) // Convert long to String
                    .collect(Collectors.joining(", "));
            return new SimpleStringProperty(deliverersIDs);
        });

        chefsIDsColumn.setCellValueFactory(data ->
        {
            Restaurant restaurant = data.getValue();
            String chefsIDs = restaurant.getChefs()
                    .stream()
                    .map(chef -> Long.toString(chef.getId())) // Convert long to String
                    .collect(Collectors.joining(", "));
            return new SimpleStringProperty(chefsIDs);
        });

        waitersIDsColumn.setCellValueFactory(data ->
        {
            Restaurant restaurant = data.getValue();
            String waitersIDs = restaurant.getWaiters()
                    .stream()
                    .map(waiter -> Long.toString(waiter.getId()))
                    .collect(Collectors.joining(", "));
            return new SimpleStringProperty(waitersIDs);
        });




        restaurantTable.setItems(restaurantObservableList);
    }

    public void filter(ActionEvent event)
    {
        ObservableList<Restaurant> restaurantObservableList = FXCollections.observableList(restaurantRepository.readFromFile());
        if (!restaurantNameInput.getText().isEmpty())
        {
            String restaurantName = restaurantNameInput.getText().toLowerCase();
            restaurantObservableList = FXCollections.observableList(
                    restaurantObservableList.stream()
                            .filter(restaurant -> restaurant.getName().toLowerCase().contains(restaurantName))
                            .toList());
        }
        if (!addressNameInput.getText().isEmpty())
        {
            String addressName = addressNameInput.getText().toLowerCase();
            restaurantObservableList.filtered(restaurant -> addressName.toLowerCase().contains(addressName.toLowerCase()));
        }

        restaurantTable.setItems(restaurantObservableList);

    }

    public void initialize()
    {
        outputRestaurantsToTable();
    }
}
