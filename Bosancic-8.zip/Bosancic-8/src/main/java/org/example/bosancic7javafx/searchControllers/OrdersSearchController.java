package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Order;
import hr.java.restaurant.model.Restaurant;
import hr.java.restaurant.repository.OrdersRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;

public class OrdersSearchController
{
    @FXML
    private TextField restaurantNameInput;

    @FXML
    private TableView<Order> ordersTable;

    @FXML
    private TableColumn<Order, Long> restaurantIdColumn;

    @FXML
    private TableColumn<Order, String> restaurantNameColumn;

    @FXML
    private TableColumn<Order, String> restaurantMealsColumn;

    @FXML
    private TableColumn<Order, String> restaurantDelivererIdColumn;

    @FXML
    private TableColumn<Order, String> restaurantDateTimeColumn;

    OrdersRepository ordersRepository = new OrdersRepository();

    public void filter(ActionEvent event)
    {
        ObservableList<Order> orders = FXCollections.observableList(ordersRepository.readFromFile());
        if (!restaurantNameInput.getText().isEmpty())
        {
            String restaurantName = restaurantNameInput.getText();
            orders  = FXCollections.observableList(
                    orders.stream().filter(order -> order.getRestaurant().getName().contains(restaurantName)).toList()
            );
        }
        ordersTable.setItems(orders);
    }

    public void displayItemsToTable()
    {
        ObservableList<Order> orders = FXCollections.observableList(ordersRepository.readFromFile());
        restaurantIdColumn.setCellValueFactory(new PropertyValueFactory<Order, Long>("id"));
        restaurantNameColumn.setCellValueFactory(
                celldata -> {
                    return new SimpleStringProperty(celldata.getValue().getRestaurant().getName());
                }
        );
        restaurantMealsColumn.setCellValueFactory(
                celldata -> {
                    Order order = celldata.getValue();
                    String mealIDs = order.getMeals()
                            .stream()
                            .map(meal -> Long.toString(meal.getId())) // Convert long to String
                            .collect(Collectors.joining(", "));
                    return new SimpleStringProperty(mealIDs);
                }
        );
        restaurantDelivererIdColumn.setCellValueFactory(
                celldata ->
                {
                    Order order = celldata.getValue();
                    return new SimpleStringProperty(String.valueOf(order.getDeliverer().getId()));
                }
        );
        restaurantDateTimeColumn.setCellValueFactory(
                celldata ->
                {
                    Order order = celldata.getValue();
                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy. HH:mm");
                    String date = order.getDeliveryDateAndTime().format(dateFormat);
                    return new SimpleStringProperty(date);
                }
        );
        ordersTable.setItems(orders);
    }

    public void initialize()
    {
        displayItemsToTable();
    }

}
