package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Waiter;
import hr.java.restaurant.model.Meal;
import hr.java.restaurant.model.Waiter;
import hr.java.restaurant.repository.WaitersRepository;
import hr.java.restaurant.repository.WaitersRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class WaitersSearchController
{
    @FXML
    private TextField waitersNameInput;

    @FXML
    private TextField waitersLastNameInput;

    @FXML
    private TableView<Waiter> waitersTableView;

    @FXML
    private TableColumn<Waiter, Long> waitersIdColumn;

    @FXML
    private TableColumn<Waiter, String> waitersNameColumn;

    @FXML
    private TableColumn<Waiter, String> waitersLastNameColumn;

    @FXML
    private TableColumn<Waiter, String> waitersContractTypeColumn;

    WaitersRepository WaitersRepository = new WaitersRepository();

    public void outputWaitersToTable()
    {
        List<Waiter> Waiters = WaitersRepository.readFromFile();
        ObservableList<Waiter> observableWaiters = FXCollections.observableArrayList(Waiters);
        waitersIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        waitersNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        waitersLastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        waitersContractTypeColumn.setCellValueFactory(cellData ->
        {
            Waiter Waiter = cellData.getValue();
            String contractType = String.valueOf(Waiter.getContract().getContractType());
            return new SimpleStringProperty(contractType);
        });
        waitersTableView.setItems(observableWaiters);
    }

    @FXML
    public void filterWaiters()
    {
        ObservableList<Waiter> observableWaiters = FXCollections.observableArrayList(WaitersRepository.readFromFile());
        if (waitersNameInput != null && !waitersNameInput.getText().isEmpty())
        {
            String filterText = waitersNameInput.getText().toLowerCase();
            observableWaiters = FXCollections.observableArrayList(
                    observableWaiters.stream()
                            .filter(Waiter -> Waiter.getFirstName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        if (waitersLastNameInput != null && !waitersLastNameInput.getText().isEmpty())
        {
            String filterText = waitersLastNameInput.getText().toLowerCase();
            observableWaiters = FXCollections.observableArrayList(
                    observableWaiters.stream()
                            .filter(Waiter -> Waiter.getLastName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        waitersTableView.setItems(observableWaiters);
    }

    @FXML
    public void initialize()
    {
        outputWaitersToTable();
    }
}
