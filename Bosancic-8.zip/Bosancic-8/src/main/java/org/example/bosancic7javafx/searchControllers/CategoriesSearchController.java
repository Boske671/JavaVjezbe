package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Category;
import hr.java.restaurant.repository.CategoriesRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class CategoriesSearchController {

    @FXML
    private Button searchButton;

    @FXML
    private TextField beveragesNameInput;

    @FXML
    private TableView<Category> categoryTable;

    @FXML
    private TableColumn<Category, Long> beveragesIDColumn;

    @FXML
    private TableColumn<Category, String> beveragesNameColumn;

    @FXML
    private TableColumn<Category, String> beveragesDescriptionColumn;

    private CategoriesRepository categoriesRepository = new CategoriesRepository();

    public void outputCategoriesToTable() {
        // Učitavanje kategorija iz repository-a
        List<Category> categories = categoriesRepository.readFromFile();

        // Pretvaranje liste u ObservableList
        ObservableList<Category> observableCategories = FXCollections.observableArrayList(categories);

        // Filtriranje kategorija na temelju unosa u beveragesNameInput
        if (beveragesNameInput != null && !beveragesNameInput.getText().isEmpty()) {
            String filterText = beveragesNameInput.getText().toLowerCase();
            observableCategories = FXCollections.observableArrayList(
                    categories.stream()
                            .filter(category -> category.getName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        beveragesIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        beveragesNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        beveragesDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));

        /*
        MOZE I OVAKO
         categoryNameColumn.setCellValueFactory(
                new Callback<TableColumn.CellDataFeatures<Category, String>, ObservableValue<String>>() {
                    @Override
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<Category, String> param) {
                        return new SimpleStringProperty(param.getValue().getName());
                    }
                }
        );

        categoryDescriptionColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDescription()));

        categoryIdColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));
         */

        // Postavljanje podataka u TableView
        categoryTable.setItems(observableCategories);
    }

    public void FilterTable()
    {

    }

    //Funckija za "postavu" scene kada se prvi put loada
    @FXML
    public void initialize() {
        outputCategoriesToTable();
    }
}
