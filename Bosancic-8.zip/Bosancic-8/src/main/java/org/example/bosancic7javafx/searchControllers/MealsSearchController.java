package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Ingredient;
import hr.java.restaurant.model.Meal;
import hr.java.restaurant.repository.IngredientsRepository;
import hr.java.restaurant.repository.MealsRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MealsSearchController {

    @FXML
    private TextField mealsNameInput;

    @FXML
    private TextField mealsPriceFromInput;

    @FXML
    private TextField mealsPriceToInput;

    @FXML
    private TableView<Meal> mealsTable;

    @FXML
    private TableColumn<Meal, Long> mealsIDColumn;

    @FXML
    private TableColumn<Meal, String> mealsNameColumn;

    @FXML
    private TableColumn<Meal, String> mealsIngredientsColumn;

    @FXML
    private TableColumn<Meal, BigDecimal> mealsPriceColumn;

    private MealsRepository mealsRepository = new MealsRepository();

    public void outputMealsToTable() {
        // Učitavanje kategorija iz repository-a
        List<Meal> meals = mealsRepository.readFromFile();

        // Pretvaranje liste u ObservableList
        ObservableList<Meal> observableMeals = FXCollections.observableArrayList(meals);

        // Filtriranje kategorija na temelju unosa u beveragesNameInput
        if (mealsNameInput != null && !mealsNameInput.getText().isEmpty()) {
            String filterText = mealsNameInput.getText().toLowerCase();
            observableMeals = FXCollections.observableArrayList(
                    meals.stream()
                            .filter(meal -> meal.getName().toLowerCase().contains(filterText))
                            .toList()
            );
        }


        BigDecimal priceFrom;
        BigDecimal priceTo;
        if (mealsPriceFromInput != null && !mealsPriceFromInput.getText().isEmpty()) {
            priceFrom = BigDecimal.valueOf(Double.parseDouble(mealsPriceFromInput.getText()));
        } else {
            priceFrom = null;
        }

        if (mealsPriceToInput != null && !mealsPriceToInput.getText().isEmpty()) {
            priceTo = BigDecimal.valueOf(Double.parseDouble(mealsPriceToInput.getText()));
        } else {
            priceTo = null;
        }

        observableMeals = FXCollections.observableArrayList(
                meals.stream()
                        .filter(meal -> (priceFrom == null || meal.getPrice().compareTo(priceFrom) >= 0)) // Filter by priceFrom if applicable
                        .filter(meal -> (priceTo == null || meal.getPrice().compareTo(priceTo) <= 0))   // Filter by priceTo if applicable
                        .toList()
        );

        mealsIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        mealsNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        mealsPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        mealsIngredientsColumn.setCellValueFactory(cellData -> {
            Meal meal = cellData.getValue(); // The Meal object for the current row
            String ingredientsIds = meal.getIngredients()
                    .stream()
                    .map(ingredient -> Long.toString(ingredient.getId())) // Convert long to String
                    .collect(Collectors.joining(", "));
            return new SimpleStringProperty(ingredientsIds); // Return as a property
        });

        // Postavljanje podataka u TableView
        mealsTable.setItems(observableMeals);
    }

    @FXML
    public void initialize() {
        outputMealsToTable();
    }
}
