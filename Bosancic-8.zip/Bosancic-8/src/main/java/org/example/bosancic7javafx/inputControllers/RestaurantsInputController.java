package org.example.bosancic7javafx.inputControllers;

import hr.java.restaurant.model.*;
import hr.java.restaurant.repository.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.util.HashSet;

public class RestaurantsInputController
{
    @FXML
    private TextField restaurantNameInput;
    @FXML
    private TextField restaurantStreetInput;
    @FXML
    private TextField restaurantHouseNumberInput;
    @FXML
    private TextField restaurantCityInput;
    @FXML
    private TextField restaurantPostalCodeInput;

    @FXML
    private ComboBox<Meal> restaurantMealsComboBox;
    @FXML
    private ComboBox<Chef> restaurantChefsComboBox;
    @FXML
    private ComboBox<Waiter> restaurantWaitersComboBox;
    @FXML
    private ComboBox<Deliverer> restaurantDeliverersComboBox;


    RestaurantRepository rr = new RestaurantRepository();
    MealsRepository mr = new MealsRepository();
    ChefsRepository cr = new ChefsRepository();
    WaitersRepository wr = new WaitersRepository();
    DeliverersRepository dr = new DeliverersRepository();

    HashSet<Meal> meals = new HashSet<>();
    HashSet<Chef> chefs = new HashSet<>();
    HashSet<Waiter> waiters = new HashSet<>();
    HashSet<Deliverer> deliverers = new HashSet<>();

    public void addItem()
    {
        boolean isValid = true;
        StringBuilder errors = new StringBuilder();

        String restaurantName = restaurantNameInput.getText();
        if (restaurantName.isEmpty()) {
            isValid = false;
            errors.append("Restaurant name cannot be empty.\n");
        }

        String restaurantStreet = restaurantStreetInput.getText();
        if (restaurantStreet.isEmpty()) {
            isValid = false;
            errors.append("Street cannot be empty.\n");
        }

        String restaurantHouseNumber = restaurantHouseNumberInput.getText();
        if (restaurantHouseNumber.isEmpty()) {
            isValid = false;
            errors.append("House number cannot be empty.\n");
        }

        String restaurantCity = restaurantCityInput.getText();
        if (restaurantCity.isEmpty()) {
            isValid = false;
            errors.append("City cannot be empty.\n");
        }

        String restaurantPostalCode = restaurantPostalCodeInput.getText();
        if (restaurantPostalCode.isEmpty()) {
            isValid = false;
            errors.append("Postal code cannot be empty.\n");
        }

        if (meals.isEmpty()) {
            isValid = false;
            errors.append("At least one meal must be added.\n");
        }

        if (chefs.isEmpty()) {
            isValid = false;
            errors.append("At least one chef must be added.\n");
        }

        if (waiters.isEmpty()) {
            isValid = false;
            errors.append("At least one waiter must be added.\n");
        }

        if (deliverers.isEmpty()) {
            isValid = false;
            errors.append("At least one deliverer must be added.\n");
        }

        if (!isValid) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(errors.toString());
            alert.showAndWait();
        } else {
            Long id = rr.readFromFile().getLast().getId() + 1;
            Address address = new Address(id, restaurantStreet, restaurantHouseNumber, restaurantCity, restaurantPostalCode);
            Restaurant restaurant = new Restaurant(id, restaurantName, address, meals, chefs, waiters, deliverers);
            rr.appendItem(restaurant);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Restaurant added successfully.");
            alert.showAndWait();

            clearHashSets();
        }
    }

    public void displayCombobox()
    {
        for (Meal meal : mr.readFromFile())
        {
            restaurantMealsComboBox.getItems().add(meal);
        }
        restaurantMealsComboBox.getSelectionModel().select(0);
        for (Chef chef : cr.readFromFile())
        {
            restaurantChefsComboBox.getItems().add(chef);
        }
        restaurantChefsComboBox.getSelectionModel().select(0);
        for (Waiter waiter : wr.readFromFile())
        {
            restaurantWaitersComboBox.getItems().add(waiter);
        }
        restaurantWaitersComboBox.getSelectionModel().select(0);
        for (Deliverer deliverer : dr.readFromFile())
        {
            restaurantDeliverersComboBox.getItems().add(deliverer);
        }
        restaurantDeliverersComboBox.getSelectionModel().select(0);
    }

    public void addMeal(ActionEvent event) {
        Meal meal = restaurantMealsComboBox.getSelectionModel().getSelectedItem();
        if (meal != null) {
            meals.add(meal);
        }
    }

    public void addChef(ActionEvent event)
    {
        Chef chef = restaurantChefsComboBox.getSelectionModel().getSelectedItem();
        if (chef != null) {
            chefs.add(chef);
        }
    }

    public void addDeliverer(ActionEvent event)
    {
        Deliverer deliverer = restaurantDeliverersComboBox.getSelectionModel().getSelectedItem();
        if (deliverer != null) {
            deliverers.add(deliverer);
        }
    }

    public void addWaiter(ActionEvent event)
    {
        Waiter waiter = restaurantWaitersComboBox.getSelectionModel().getSelectedItem();
        if (waiter != null) {
            waiters.add(waiter);
        }
    }

    public void clearHashSets()
    {
        meals.clear();
        chefs.clear();
        deliverers.clear();
        waiters.clear();
    }

    public void initialize()
    {
        displayCombobox();
    }
}
