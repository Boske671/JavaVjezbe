package org.example.bosancic7javafx.searchControllers;

import hr.java.restaurant.model.Category;
import hr.java.restaurant.model.Ingredient;
import hr.java.restaurant.repository.IngredientsRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.math.BigDecimal;
import java.util.List;

public class IngredientsSearchController
{

    @FXML
    private TextField ingredientsNameInput;

    @FXML
    private TextField ingredientsKcalFromInput;

    @FXML
    private TextField ingredientsKcalToInput;

    @FXML
    private TableView<Ingredient> ingredientsTable;

    @FXML
    private TableColumn<Ingredient, Long> ingredientsIDColumn;

    @FXML
    private TableColumn<Ingredient, String> ingredientsNameColumn;

    @FXML
    private TableColumn<Ingredient, String> ingredientsKcalColumn;

    @FXML
    private TableColumn<Ingredient, String> ingredientsPreperationMethodColumn;

    private IngredientsRepository ingredientsRepository = new IngredientsRepository();


    public void outputIngredientsToTable()
    {
        // Učitavanje kategorija iz repository-a
        List<Ingredient> ingredients = ingredientsRepository.readFromFile();

        // Pretvaranje liste u ObservableList
        ObservableList<Ingredient> observableIngredients = FXCollections.observableArrayList(ingredients);

        // Filtriranje kategorija na temelju unosa u beveragesNameInput
        if (ingredientsNameInput != null && !ingredientsNameInput.getText().isEmpty())
        {
            String filterText = ingredientsNameInput.getText().toLowerCase();
            observableIngredients = FXCollections.observableArrayList(
                    observableIngredients.stream()
                            .filter(ingredient -> ingredient.getName().toLowerCase().contains(filterText))
                            .toList()
            );
        }

        BigDecimal kcalFrom;
        BigDecimal kcalTo;
        if (ingredientsKcalFromInput != null && !ingredientsKcalFromInput.getText().isEmpty())
        {
            kcalFrom = BigDecimal.valueOf(Double.parseDouble(ingredientsKcalFromInput.getText()));
        } else
        {
            kcalFrom = null;
        }

        if (ingredientsKcalToInput != null && !ingredientsKcalToInput.getText().isEmpty())
        {
            kcalTo = BigDecimal.valueOf(Double.parseDouble(ingredientsKcalToInput.getText()));
        }
        else
        {
            kcalTo = null;
        }

        observableIngredients = FXCollections.observableArrayList(
                ingredients.stream()
                        .filter(ingredient -> (kcalFrom == null || ingredient.getKcal().compareTo(kcalFrom) >= 0)) // Filter by priceFrom
                        .filter(ingredient -> (kcalTo == null || ingredient.getKcal().compareTo(kcalTo) <= 0))  // Filter by priceTo
                        .toList()
        );

        ingredientsIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        ingredientsNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        ingredientsKcalColumn.setCellValueFactory(new PropertyValueFactory<>("kcal"));
        ingredientsPreperationMethodColumn.setCellValueFactory(new PropertyValueFactory<>("preparationMethod"));

        // Postavljanje podataka u TableView
        ingredientsTable.setItems(observableIngredients);
    }

    @FXML
    public void initialize()
    {
        outputIngredientsToTable();
    }
}
