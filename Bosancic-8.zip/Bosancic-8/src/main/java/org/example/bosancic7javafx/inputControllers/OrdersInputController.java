package org.example.bosancic7javafx.inputControllers;

import hr.java.restaurant.model.Deliverer;
import hr.java.restaurant.model.Meal;
import hr.java.restaurant.model.Order;
import hr.java.restaurant.model.Restaurant;
import hr.java.restaurant.repository.DeliverersRepository;
import hr.java.restaurant.repository.MealsRepository;
import hr.java.restaurant.repository.OrdersRepository;
import hr.java.restaurant.repository.RestaurantRepository;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class OrdersInputController
{
    @FXML
    private ComboBox<Restaurant> restaurantComboBox;
    @FXML
    private ComboBox<Meal> restaurantMealsComboBox;
    @FXML
    private ComboBox<Deliverer> delivererComboBox;
    @FXML
    private TextField dateAndTimeInput;

    OrdersRepository ordersRepository = new OrdersRepository();
    RestaurantRepository rr = new RestaurantRepository();
    MealsRepository mealsRepository = new MealsRepository();
    DeliverersRepository deliverersRepository = new DeliverersRepository();

    List<Meal> meals = new ArrayList<>();

    public void addItem()
    {
        boolean isValid = true;
        StringBuilder errors = new StringBuilder();

        Restaurant restaurant = restaurantComboBox.getSelectionModel().getSelectedItem();
        if (restaurant == null) {
            isValid = false;
            errors.append("A restaurant must be selected.\n");
        }

        Deliverer deliverer = delivererComboBox.getSelectionModel().getSelectedItem();
        if (deliverer == null) {
            isValid = false;
            errors.append("A deliverer must be selected.\n");
        }

        if (meals.isEmpty()) {
            isValid = false;
            errors.append("At least one meal must be added.\n");
        }

        String dateAndTime = dateAndTimeInput.getText();
        LocalDateTime dateTime = null;
        if (dateAndTime.isEmpty()) {
            isValid = false;
            errors.append("Date and time cannot be empty.\n");
        } else {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy. HH:mm");
                dateTime = LocalDateTime.parse(dateAndTime, formatter);
            } catch (Exception e) {
                isValid = false;
                errors.append("Invalid date and time format. Use dd.MM.yyyy. HH:mm.\n");
            }
        }

        if (!isValid) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(errors.toString());
            alert.showAndWait();
        } else {
            Long id = ordersRepository.readFromFile().getLast().getId() + 1;
            Order order = new Order(id, restaurant, meals, deliverer, dateTime);
            ordersRepository.appendItem(order);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Order added successfully.");
            alert.showAndWait();

            meals.clear();
        }
    }

    public void displayCombobox()
    {
        for (Restaurant restaurant : rr.readFromFile()) {
            restaurantComboBox.getItems().add(restaurant);
        }
        restaurantComboBox.getSelectionModel().select(0);

        for (Meal meal : mealsRepository.readFromFile()) {
            restaurantMealsComboBox.getItems().add(meal);
        }
        restaurantMealsComboBox.getSelectionModel().select(0);

        for (Deliverer deliverer : deliverersRepository.readFromFile()) {
            delivererComboBox.getItems().add(deliverer);
        }
        delivererComboBox.getSelectionModel().select(0);
    }

    public void addMeal(ActionEvent event)
    {
        Meal meal = restaurantMealsComboBox.getSelectionModel().getSelectedItem();
        if (meal != null) {
            meals.add(meal);
        }
    }

    public void initialize()
    {
        displayCombobox();
    }
}
