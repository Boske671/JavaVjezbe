module org.example.bosancic7javafx {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.slf4j;


    //POTREBNO
    requires javafx.base;

    // Open the hr.java.restaurant.model package to javafx.base
    // ISTO POTREBNO
    opens hr.java.restaurant.model to javafx.base;
    opens org.example.bosancic7javafx to javafx.fxml;
    opens org.example.bosancic7javafx.inputControllers to javafx.fxml;

    exports org.example.bosancic7javafx;
    exports org.example.bosancic7javafx.searchControllers;
    exports org.example.bosancic7javafx.inputControllers;
    opens org.example.bosancic7javafx.searchControllers to javafx.fxml;
}